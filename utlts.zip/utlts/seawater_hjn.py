import numpy as np
import torch


class SW():
    #判断列表中是否存在不一样的元素
    def have_unique_elements(self, sizes):
        unique_values = set(sizes)
        return len(unique_values) > 1


    #计算海水绝热温度梯度
    def sw_adtg(self, S, T, P):

        if not torch.is_tensor(S):
            S = torch.from_numpy(S)
        if not torch.is_tensor(T):
            T = torch.from_numpy(T)
        if not torch.is_tensor(P):
            P = torch.from_numpy(P)
        if len([S, T, P]) != 3:
            return 'sw_adtg: Must pass 3 parameters'

        #判断维度数量是否相等
        if len(S.shape) != len(T.shape):
            return 'sw_adtg:matrix dimension error'

        #判断每个维度是否相等
        for i in range(0, len(S.shape)):
            dimension_value = [S.shape[i], T.shape[i], P.shape[i]]
            if self.have_unique_elements(dimension_value):
                return 'sw_adtg:S,T,P have different dimensions'

        T68 = 1.00024 * T

        a0 = 3.5803E-5
        a1 = +8.5258E-6
        a2 = -6.836E-8
        a3 = 6.6228E-10

        b0 = +1.8932E-6
        b1 = -4.2393E-8

        c0 = +1.8741E-8
        c1 = -6.7795E-10
        c2 = +8.733E-12
        c3 = -5.4481E-14

        d0 = -1.1351E-10
        d1 = 2.7759E-12

        e0 = -4.6206E-13
        e1 = +1.8676E-14
        e2 = -2.1687E-16

        ADTG = a0 + (a1 + (a2 + a3 * T68) * T68) * T68 + (b0 + b1 * T68) * (S - 35) \
               + ((c0 + (c1 + (c2 + c3 * T68) * T68) * T68) + (d0 + d1 * T68)
                  * (S - 35)) * P + (e0 + (e1 + e2 * T68) * T68) * P * P

        return ADTG


    #计算海水位势温度
    def sw_ptmp(self, S, T, P, PR):
        if not torch.is_tensor(S):
            S = torch.from_numpy(S)
        if not torch.is_tensor(T):
            T = torch.from_numpy(T)
        if not torch.is_tensor(P):
            P = torch.from_numpy(P)
        if not torch.is_tensor(PR):
            PR = torch.from_numpy(PR)
        if len([S, T, P, PR]) != 4:
            return 'sw_ptmp: Must pass 4 parameters'

        #判断维度数量是否相等
        if len(S.shape) != len(T.shape):
            return 'sw_ptmp:matrix dimension error'

        #判断每个维度是否相等
        for i in range(0, len(S.shape)):
            dimension_value = [S.shape[i], T.shape[i], P.shape[i], PR.shape[i]]
            if self.have_unique_elements(dimension_value):
                return 'sw_ptmp:S,T,P,PR have different dimensions'

        del_P = PR - P
        del_th = del_P * self.sw_adtg(S, T, P)
        th = T * 1.00024 + 0.5 * del_th
        q = del_th

        del_th = del_P * self.sw_adtg(S, th / 1.00024, P + 0.5 * del_P)
        th = th + (1 - 1 / np.sqrt(2)) * (del_th - q)
        q = (2 - np.sqrt(2)) * del_th + (-2 + 3 / np.sqrt(2)) * q

        del_th = del_P * self.sw_adtg(S, th / 1.00024, P + 0.5 * del_P)
        th = th + (1 + 1 / np.sqrt(2)) * (del_th - q)
        q = (2 + np.sqrt(2)) * del_th + (-2 - 3 / np.sqrt(2)) * q

        del_th = del_P * self.sw_adtg(S, th / 1.00024, P + del_P)
        PT = (th + (del_th - 2 * q) / 6) / 1.00024
        return PT


    #计算海水密度
    def sw_dens(self, S, T, P):
        if not torch.is_tensor(S):
            S = torch.from_numpy(S)
        if not torch.is_tensor(T):
            T = torch.from_numpy(T)
        if not torch.is_tensor(P):
            P = torch.from_numpy(P)
        if len([S, T, P]) != 3:
            return 'sw_dens: Must pass 3 parameters'

            # 判断维度数量是否相等
        if len(S.shape) != len(T.shape):
            return 'sw_dens.py:matrix dimension error'

            # 判断每个维度是否相等
        for i in range(0, len(S.shape)):
            dimension_value = [S.shape[i], T.shape[i], P.shape[i]]
            if self.have_unique_elements(dimension_value):
                return 'sw_dens:S,T,P have different dimensions'

        densP0 = self.sw_dens0(S, T)
        K = self.sw_seck(S, T, P)
        P = P/10
        dens = densP0/(1 - P/K)
        return dens


    #计算大气压下的海水密度
    def sw_dens0(self, S, T):
        if not torch.is_tensor(S):
            S = torch.from_numpy(S)
        if not torch.is_tensor(T):
            T = torch.from_numpy(T)

        T68 = T * 1.00024

        b0 = 8.24493e-1
        b1 = -4.0899e-3
        b2 = 7.6438e-5
        b3 = -8.2467e-7
        b4 = 5.3875e-9
        c0 = -5.72466e-3
        c1 = +1.0227e-4
        c2 = -1.6546e-6
        d0 = 4.8314e-4
        dens = self.smow(T) + (b0 + (b1 + (b2 + (b3 + b4*T68)*T68)*T68)*T68)*S + (c0 + (c1 + c2*T68)*T68)*S*torch.sqrt(S) + d0*S**2
        return dens


    #标准平均海水（纯水）的密度
    def smow(self, T):
        if not torch.is_tensor(T):
            T = torch.from_numpy(T)

        a0 = 999.842594
        a1 = 6.793952e-2
        a2 = -9.095290e-3
        a3 = 1.001685e-4
        a4 = -1.120083e-6
        a5 = 6.536332e-9

        T68 = T * 1.00024
        result = a0 + (a1 + (a2 + (a3 + (a4 + a5*T68)*T68)*T68)*T68)*T68
        return result


    #海水的切体积模量
    def sw_seck(self, S, T, P):
        if not torch.is_tensor(S):
            S = torch.from_numpy(S)
        if not torch.is_tensor(T):
            T = torch.from_numpy(T)
        if not torch.is_tensor(P):
            P = torch.from_numpy(P)
        if len([S, T, P]) != 3:
            return 'sw_seck: Must pass 3 parameters'

            # 判断维度数量是否相等
        if len(S.shape) != len(T.shape):
            return 'sw_seck:matrix dimension error'

            # 判断每个维度是否相等
        for i in range(0, len(S.shape)):
            dimension_value = [S.shape[i], T.shape[i], P.shape[i]]
            if self.have_unique_elements(dimension_value):
                return 'sw_seck:S,T,P have different dimensions'

        P = P/10
        T68 = T * 1.00024

        h3 = -5.77905E-7
        h2 = +1.16092E-4
        h1 = +1.43713E-3
        h0 = +3.239908

        AW = h0 + (h1 + (h2 + h3 * T68) * T68) * T68

        k2 = 5.2787E-8
        k1 = -6.12293E-6
        k0 = +8.50935E-5

        BW = k0 + (k1 + k2 * T68) * T68

        e4 = -5.155288E-5
        e3 = +1.360477E-2
        e2 = -2.327105
        e1 = +148.4206
        e0 = 19652.21

        KW = e0 + (e1 + (e2 + (e3 + e4 * T68) * T68) * T68) * T68

        j0 = 1.91075E-4

        i2 = -1.6078E-6
        i1 = -1.0981E-5
        i0 = 2.2838E-3

        SR = torch.sqrt(S)

        A = AW + (i0 + (i1 + i2 * T68) * T68 + j0 * SR) * S

        m2 = 9.1697E-10
        m1 = +2.0816E-8
        m0 = -9.9348E-7

        B = BW + (m0 + (m1 + m2 * T68) * T68) * S

        f3 = -6.1670E-5
        f2 = +1.09987E-2
        f1 = -0.603459
        f0 = +54.6746

        g2 = -5.3009E-4
        g1 = +1.6483E-2
        g0 = +7.944E-2

        K0 = KW + (f0 + (f1 + (f2 + f3 * T68) * T68) * T68 + (g0 + (g1 + g2 * T68) * T68) * SR) * S

        K = K0 + (A + B * P) * P
        return K


    #海水位势密度
    def sw_pden(self, S, T, P, PR):
        if not torch.is_tensor(S):
            S = torch.from_numpy(S)
        if not torch.is_tensor(T):
            T = torch.from_numpy(T)
        if not torch.is_tensor(P):
            P = torch.from_numpy(P)
        if not torch.is_tensor(PR):
            PR = torch.from_numpy(PR)
        if len([S, T, P, PR]) != 4:
            return 'sw_ptmp: Must pass 4 parameters'

        #判断维度数量是否相等
        if len(S.shape) != len(T.shape):
            return 'sw_ptmp:matrix dimension error'

        #判断每个维度是否相等
        for i in range(0, len(S.shape)):
            dimension_value = [S.shape[i], T.shape[i], P.shape[i], PR.shape[i]]
            if self.have_unique_elements(dimension_value):
                return 'sw_ptmp:S,T,P,PR have different dimensions'

        ptmp = self.sw_ptmp(S, T, P, PR)
        pden = self.sw_dens(S, ptmp, PR)
        return pden
