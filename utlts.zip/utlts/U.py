#!/usr/bin/env python
import numpy as np
import os
#import tifffile as tiff
# import cv2
import time
import math
import torch
#import matplotlib.pyplot as plt
from PIL import Image
#from sklearn.metrics import cohen_kappa_score
#import xlwings as xw

def adjust_learning_rate(params, optimizer, epoch):
    """Sets the learning rate to the initial LR decayed by 10 every args.step epochs"""
    lr = params['learning_rate'] * (0.8 ** (epoch // params['lr_changestep']))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

    return lr

def image_normalizer(img_trans, params, type='enhance_contrast'):
    """
    Clip an image at certain threshold value, and then normalize to values between 0 and 1.
    Threshold is used for contrast enhancement.
    """
    # img_norm = np.clip(img_trans, 0, params['norm_threshold'])
    # img_norm = img_norm / params['norm_threshold']
    # image_normalizer. ref from RS-net utils https://github.com/JacobJeppesen/RS-Net
    # if type == 'enhance_contrast':  # Enhance contrast of entire image
    #     # Here we clip and normalize to value between 0 and 1
    #     img_norm = np.clip(img_trans, 0, params['norm_threshold'])
    #     img_norm = img_norm / params['norm_threshold']
        
    # elif type == 'running_normalization':  # Normalize each band of each incoming image based on that image
    #     # Based on stretch_n function found at https://www.kaggle.com/drn01z3/end-to-end-baseline-with-u-net-keras
    min_value = 0
    max_value = 1
    lower_percent = 2  # Used to discard lower bound outliers
    higher_percent = 98  # Used to discard upper bound outliers
    bands = img_trans.shape[0]
    img_norm = np.zeros_like(img_trans)
    for i in range(bands):
        c = np.percentile(img_trans[i, :, :], lower_percent)
        d = np.percentile(img_trans[i, :, :], higher_percent)
        if np.abs( d - c) < 1.0e-6:
            t = min_value + (img_trans[i, :, :] - c) * (max_value - min_value)
        else:
            t = min_value + (img_trans[i, :, :] - c) * (max_value - min_value) / (d - c)                
        t[t < min_value] = min_value
        t[t > max_value] = max_value
        img_norm[i, :, :] = t
    # elif type == 'landsat8_normalization':  # Normalize each band of each incoming image based on Landsat8 Biome
    #     # Standard deviations used for standardization
    #     std_devs = 4
    #     # Normalizes to zero mean and half standard deviation (find values in 'jhj_InspectLandsat8Data' notebook)
    #     img_norm = np.zeros_like(img_trans)
    #     img_norm[:, :, 0] = (img_trans[:, :, 0] - 4112) / (std_devs * 1488) # B4
    #     img_norm[:, :, 1] = (img_trans[:, :, 1] - 4013) / (std_devs * 1385) # B3
    #     img_norm[:, :, 2] = (img_trans[:, :, 2] - 4435) / (std_devs * 1414) # B2
    #     img_norm[:, :, 3] = (img_trans[:, :, 3] - 4776) / (std_devs * 1522) # B5            
    img_trans = img_norm #.transpose((2, 0, 1)) # HWC to CHW    
    return img_trans    

def slice_2Dmatrix(array, window, overlap):
    # array should be HWC
    
    # Calculate steps
    steps_x = int(math.ceil((array.shape[0] - overlap[0]) /
                            float(window[0] - overlap[0])))
    steps_y = int(math.ceil((array.shape[1] - overlap[1]) /
                            float(window[1] - overlap[1])))

    # Iterate over it x,y
    patches = []
    for x in range(0, steps_x):
        for y in range(0, steps_y):
            # Define window edges
            x_start = x*window[0] - x*overlap[0]
            x_end = x_start + window[0]
            y_start = y*window[1] - y*overlap[1]
            y_end = y_start + window[1]
            # Adjust ends
            if(x_end > array.shape[0]):
                # Create an overlapping patch for the last images / edges
                # to ensure the fixed patch/window sizes
                x_start = array.shape[0] - window[0]
                x_end = array.shape[0]
                # Fix for MRIs which are smaller than patch size
                if x_start < 0 : x_start = 0 
            if(y_end > array.shape[1]):
                y_start = array.shape[1] - window[1]
                y_end = array.shape[1]
                # Fix for MRIs which are smaller than patch size
                if y_start < 0 : y_start = 0
            # Cut window
            window_cut = array[x_start:x_end,y_start:y_end]
            # Add to result list
            patches.append(window_cut)
    return patches

# Concatenate a list of patches together to a numpy matrix
def concat_2Dmatrices(patches, image_size, window, overlap):
    # Calculate steps
    steps_x = int(math.ceil((image_size[0] - overlap[0]) /
                            float(window[0] - overlap[0])))
    steps_y = int(math.ceil((image_size[1] - overlap[1]) /
                            float(window[1] - overlap[1])))

    # Iterate over it x,y,z
    matrix_x = None
    matrix_y = None
    pointer = 0
    for x in range(0, steps_x):
        for y in range(0, steps_y):
            # Calculate pointer from 2D steps to 1D list of patches
            pointer = x*steps_y + y
            # Connect current tmp Matrix Z to tmp Matrix Y
            if y == 0:
                matrix_y = patches[pointer]
            else:
                matrix_p = patches[pointer]
                # Handle y-axis overlap
                slice_overlap = calculate_overlap(y, steps_y, overlap,
                                                  image_size, window, 1)
                matrix_y, matrix_p = handle_overlap(matrix_y, matrix_p,
                                                    slice_overlap,
                                                    axis=1)
                matrix_y = np.concatenate((matrix_y, matrix_p), axis=1)
        # Connect current tmp Matrix Y to final Matrix X
        if x == 0:
            matrix_x = matrix_y
        else:
            # Handle x-axis overlap
            slice_overlap = calculate_overlap(x, steps_x, overlap,
                                              image_size, window, 0)
            matrix_x, matrix_y = handle_overlap(matrix_x, matrix_y,
                                                slice_overlap,
                                                axis=0)
            matrix_x = np.concatenate((matrix_x, matrix_y), axis=0)
    # Return final combined matrix
    return(matrix_x)

# Calculate the overlap of the current matrix slice
def calculate_overlap(pointer, steps, overlap, image_size, window, axis):
    # Overlap: IF last axis-layer -> use special overlap size
    if pointer == steps-1 and not (image_size[axis]-overlap[axis]) \
        % (window[axis]-overlap[axis]) == 0:
            current_overlap = window[axis] - \
                (image_size[axis] - overlap[axis]) % \
                    (window[axis] - overlap[axis])
    # Overlap: ELSE -> use default overlap size
    else:
        current_overlap = overlap[axis]
    return current_overlap

# Handle the overlap of two overlapping matrices
def handle_overlap(matrixA, matrixB, overlap, axis):
    # Access overllaping slice from matrix A
    idxA = [slice(None)] * matrixA.ndim
    matrixA_shape = matrixA.shape
    idxA[axis] = range(matrixA_shape[axis] - overlap, matrixA_shape[axis])
    sliceA = matrixA[tuple(idxA)]
    # Access overllaping slice from matrix B
    idxB = [slice(None)] * matrixB.ndim
    idxB[axis] = range(0, overlap)
    sliceB = matrixB[tuple(idxB)]
    # Calculate Average prediction values between the two matrices
    # and save them in matrix A
    matrixA[tuple(idxA)] = np.mean(np.array([sliceA, sliceB]), axis=0)
    # Remove overlap from matrix B
    matrixB = np.delete(matrixB, [range(0, overlap)], axis=axis)
    # Return processed matrices
    return matrixA, matrixB

def predict_img_torch(net, params, img):
    # img : HWC 
    # normalize the image
    # img0 = image_normalizer(img, params) # img0 : CHW
    '''
        dimension of img_patched  : HWC
        dimension of img_patch2Use: CHW
    '''
    img_patched = slice_2Dmatrix(img, params['patch_size'], params['overlap'])
    indice2use = []
    for i in range(len(img_patched)):
        _img = img_patched[i].transpose((2, 0, 1)) # HWC --> CHW
        if np.any(_img == 0): # if any black pixels
            if np.mean(_img != 0): # Ignore completely black patches
                indice2use.append(i)
                # fill the black pixels
                for j in range(0, _img.shape[0]):
                    if np.mean(_img[j, :, :]) == 0:
                        mean_value = np.mean(_img[_img != 0])
                    else:
                        mean_value = np.mean(_img[j, _img[j, :, :] != 0])
                    _img[j, _img[j, :, :] == 0] = mean_value
                img_patched[i] = _img.transpose((1, 2, 0))
        else:
            indice2use.append(i)
    img_patch2Use     = [img_patched[i].transpose((2, 0, 1)) for i in indice2use]
    predicted_patches = np.zeros((len(img_patched),
                                  params['patch_size'][0], params['patch_size'][1],1))
    probs_pred = [] 
    for img2pred in img_patch2Use:
        # img2pred : CHW
        img2pred  = image_normalizer(img2pred, params)
        _img = torch.from_numpy(img2pred)
        _img = _img.unsqueeze(0)
        _img = _img.to(device = params['device'], dtype = torch.float32)
        net.eval()
        with torch.no_grad():
            output = net(_img)
            probs  = torch.sigmoid(output)
            full_mask = probs.squeeze().cpu().numpy()
            probs_pred.append(full_mask)
    probs_ = np.asarray(probs_pred)
    predicted_patches[indice2use,:,:,:] = probs_[:,:,:,np.newaxis]
    pred_patch2stitch = []
    [pred_patch2stitch.append(predicted_patches[_,:,:,:]) for _ in range(predicted_patches.shape[0])]
    predicted_stitched = concat_2Dmatrices(pred_patch2stitch, img.shape[0:2],
                                           params['patch_size'], params['overlap'])
    # Throw away the inpainting of the zero pixels in the individual patches
    # The summation is done to ensure that all pixels are included. The bands do not perfectly overlap (!)
    predicted_stitched[np.sum(img, axis=2) == 0] = 0
    # Threshold the prediction
    #predicted_binary_mask = predicted_stitched >= np.float32(params['threshold'])

    return predicted_stitched #, predicted_binary_mask
    
def plot_img_and_mask(img, mask):
    plt.close('all')
    classes = mask.shape[2] if len(mask.shape) > 2 else 1
    fig, ax = plt.subplots(1, classes + 1)
    ax[0].set_title('Input image')
    ax[0].imshow(img)
    if classes > 1:
        for i in range(classes):
            ax[i+1].set_title(f'Output mask (class {i+1})')
            ax[i+1].imshow(mask[:, :, i])
    else:
        ax[1].set_title(f'Output mask')
        ax[1].imshow(mask)
    plt.xticks([]), plt.yticks([])
    plt.show()


def calculate_evaluation_criteria(valid_pixels_mask, predicted_binary_mask, true_binary_mask):
    # From https://www.kaggle.com/lopuhin/full-pipeline-demo-poly-pixels-ml-poly
    # with correction for toggling true/false from
    # https://stackoverflow.com/questions/39164786/invert-0-and-1-in-a-binary-array
    # Need to AND with the a mask showing where there are pixels to avoid including pixels with value=0

    # Count number of actual pixels
    npix = valid_pixels_mask.sum()
    predicted_binary_mask = np.squeeze(predicted_binary_mask)
    true_binary_mask = np.squeeze(true_binary_mask)

    if np.ndim(predicted_binary_mask) == 3:
        tp = ((predicted_binary_mask[:, :, 0] & true_binary_mask[:, :, 0]) & valid_pixels_mask).sum()
        fp = ((predicted_binary_mask[:, :, 0] & (1 - true_binary_mask)[:, :, 0]) & valid_pixels_mask).sum()
        fn = (((1 - predicted_binary_mask)[:, :, 0] & true_binary_mask[:, :, 0]) & valid_pixels_mask).sum()
        # tn = (((1 - predicted_binary_mask)[:, :, 0] & (1 - true_binary_mask)) & actual_pixels_mask).sum()
        tn = npix - tp - fp - fn

    else:
        tp = ((predicted_binary_mask & true_binary_mask) & valid_pixels_mask).sum()
        fp = ((predicted_binary_mask & (1 - true_binary_mask)) & valid_pixels_mask).sum()
        fn = (((1 - predicted_binary_mask) & true_binary_mask) & valid_pixels_mask).sum()
        # tn = (((1 - predicted_binary_mask) & (1 - true_binary_mask)) & actual_pixels_mask).sum()
        tn = npix - tp - fp - fn

    # Calculate metrics
    accuracy = (tp + tn) / npix
    if tp != 0:
        precision = tp / (tp + fp)
        recall = tp / (tp + fn)
        f_one_score = 2 * (precision * recall) / (precision + recall)
        # See https://en.wikipedia.org/wiki/Jaccard_index#Similarity_of_asymmetric_binary_attributes
        pixel_jaccard = tp / (tp + fp + fn)
    else:
        precision = recall = f_one_score = pixel_jaccard = 0

    # Metrics from Foga 2017 paper
    if fp != 0:
        omission = fp / (tp + fp)
        comission = fp / (tn + fn)

    else:
        omission = comission = 0
    y_true = true_binary_mask[valid_pixels_mask > 0.5]
    y_pred = predicted_binary_mask[valid_pixels_mask > 0.5]
    kappa_value = cohen_kappa_score(np.reshape(y_true, (-1, 1)), np.reshape(y_pred, (-1, 1)))
    return accuracy, omission, comission, pixel_jaccard, precision, recall, f_one_score, tp, tn, fp, fn, npix, kappa_value

def overlay_images(background, overlay, transparency):
    '''
    Overlay a mask on an RGB image
    '''
    # See https://stackoverflow.com/questions/765736/using-pil-to-make-all-white-pixels-transparent
    # and https://stackoverflow.com/questions/10640114/overlay-two-same-sized-images-in-python
    overlay = overlay.convert("RGBA")
    background = background.convert("RGBA")
    datas = overlay.getdata()
    newData = []
    for item in datas:
        if item[0] == 0:
            newData.append((0, 0, 0, 0))  # Makes it completely transparent
        else:
            newData.append((255, 120, 0, transparency))  # The pixel values for '1' in the mask
    overlay.putdata(newData)

    return Image.alpha_composite(background, overlay)

def fill_borad(rgb, valid_pixels):
    '''
        fill blank
        rgb : [h, w, 3]
        valid_pixels: [h, w]
    '''

    for i in range(0, 3):
        aa = rgb[:, :, i]
        aa[valid_pixels == 0] = 0
        rgb[:, :, i] = aa
    return rgb

def write_xls_file(evaluation_metrics, params):

    file_name = os.path.join(params['checkpoint_path'], \
                             'param_optimization_Train_Eval.xlsx')
    # Create xls file
    wb = xw.Book()
    fileTemp = list(evaluation_metrics)[0]
    thresholds = list(evaluation_metrics[fileTemp])
    for threshold in thresholds:
        wb.sheets.add(threshold)
        sht = wb.sheets[threshold]
        for i, file in enumerate(list(evaluation_metrics)):
            if i == 1:
                allKey = ['Filename']
                for key in (evaluation_metrics[file][threshold]):
                    allKey.append(key)
                sht.range('A1').value = allKey
            res2write = [file]
            for key in (evaluation_metrics[file][threshold]):
                res2write.append(evaluation_metrics[file][threshold][key])
            sht.range(['A' + str(i+1)]).value = res2write

    wb.save(file_name)


def model_summary(model):
  print("model_summary")
  print()
  print("Layer_name"+"\t"*7+"Number of Parameters")
  print("="*100)
  model_parameters = [layer for layer in model.parameters() if layer.requires_grad]
  layer_name = [child for child in model.children()]
  j = 0
  total_params = 0
  print("\t"*10)
  for i in layer_name:
    print()
    param = 0
    try:
      bias = (i.bias is not None)
    except:
      bias = False  
    if not bias:
      param =model_parameters[j].numel()+model_parameters[j+1].numel()
      j = j+2
    else:
      param =model_parameters[j].numel()
      j = j+1
    print(str(i)+"\t"*3+str(param))
    total_params+=param
  print("="*100)
  print(f"Total Params:{total_params}") 


def series_to_superised_inOut_2d(var2superised, n_in, n_out):
    nsteps = var2superised.shape[0]
    nlat = var2superised.shape[1]
    nlon = var2superised.shape[2]
    nt = n_in
    ncols = int(nsteps - n_out - n_in )  # lower bound are 0 .
    train_cols = []  # np.zeros((ncols, 12), dtype = int)
    for ii in range(ncols):
        if ii == 0:
            #colTemp = np.linspace(0, n_in - 1, n_in)
            colTemp = np.linspace(0, nt - 1, nt)
            train_cols.append([int(_) for _ in colTemp])
        else:
            colTemp = colTemp + 1
            train_cols.append([int(_) for _ in colTemp])
    resAll_in = np.zeros((ncols, nt, nlat, nlon), dtype=float)
    for ii in range(ncols):
        resAll_in[ii, :, :, :] = var2superised[np.asarray(train_cols[ii]), :, :]
    return resAll_in