#!/usr/bin/env python3
# -*- coding: cp1252 -*-
import netCDF4 as netcdf
import numpy as np
#import matplotlib
import pandas as pd
import torch.nn as nn
import torch
from datetime import datetime,timedelta
import os


def import_data():
	fdir=r'D:/02-Data/DRS/'
	target_nc = fdir+"RG_ArgoClim_Psal.nc"
	nc = netcdf.Dataset(target_nc)
	startDate = datetime(1999,11,1); endDate= datetime(2014,11,30); 
	time=pd.date_range(startDate,endDate,freq='M')+timedelta(1)-datetime(1900,1,1)
	t1=np.asarray([time[ii].total_seconds()/86400 for ii in range(1,len(time))])
	nc.close()

	target_nc = fdir+"sst.mnmean.nc"
	#nc.variables["time"]
	nc = netcdf.Dataset(target_nc)
	time=nc.variables["time"][:].data - 36524
	#ST.time=[timedelta(time[ii])+datetime(1800,1,1) for ii in range(1,len(time))]
	t2=time.tolist()  #1800,1,1 to 1900,1,1
	nc.close()


	target_nc = fdir+"zos_AVISO_L4_199210-201012.nc"
	nc = netcdf.Dataset(target_nc)
	time =nc.variables["time"][:].data + ( (datetime(1950,1,1) - datetime(1900,1,1)).total_seconds()/86400)
	#SH.time=[timedelta(time[ii])+datetime(1950,1,1) for ii in range(1,len(time))]
	t3 = time.tolist()
	nc.close()

	# target_nc = "D:/02-Data/CCMPv2_monthly/2000s/*.nc" 
	# nc = netcdf.MFDataset(target_nc,aggdim='time')
	# t4 = nc.variables["time"][:]/24 + ( (datetime(1987,1,1) - datetime(1900,1,1)).total_seconds()/86400)
	# nc.close()

	tmin=max([min(t1),min(t2),min(t3)])
	tmax=min([max(t1),max(t2),max(t3)])

	#mt1=np.where((np.array(t1)>=tmin) & (np.array(t1)<=tmax))
	#mt2=np.where((np.array(t2)>=tmin) & (np.array(t2)<=tmax))
	#mt3=np.where((np.array(t3)>=tmin) & (np.array(t3)<=tmax))

	mt1=np.intersect1d(np.where(np.array(t1)>=tmin),np.where(np.array(t1)<=tmax))
	mt2=np.intersect1d(np.where(np.array(t2)>=tmin),np.where(np.array(t2)<=tmax))
	mt3=np.intersect1d(np.where(np.array(t3)>=tmin),np.where(np.array(t3)<=tmax))
	# mt4=np.intersect1d(np.where(np.array(t4)>=tmin),np.where(np.array(t4)<=tmax))
	mt1=mt1[:]
	mt2=mt2[:]
	mt3=mt3[:] #0:12
	# mt4=mt4[:] #0:12


	target_nc = fdir+"RG_ArgoClim_Psal.nc"
	nc = netcdf.Dataset(target_nc)
	lon=nc.variables["LONGITUDE"][:].data-20
	lat=nc.variables["LATITUDE"][2:131].data
	z = nc.variables["PRESSURE"][:].data.reshape(-1,1)
	nc.close()

	# target_nc = fdir+"RG_ArgoClim_Psal.nc"
	# nc = netcdf.Dataset(target_nc)
	# S=nc.variables["ARGO_SALINITY_ANOMALY"][mt1,:,2:131,:]
	# S = np.concatenate((S[:,:,340:360],S[:,:,0:339]),2)
	# Smean = nc.variables["ARGO_SALINITY_MEAN"][:,2:131,:]
	# Smean = np.concatenate((Smean[:,:,340:361],Smean[:,:,0:340]),2)
	# nc.close()

	target_nc = fdir+"RG_ArgoClim_Temp.nc"
	nc = netcdf.Dataset(target_nc)
	#T=nc.variables["ARGO_TEMPERATURE_ANOMALY"][mt1,:,2:131,:]
	T=nc.variables["STA"][mt1,:,2:131,:]
	T=np.concatenate((T[:,:,340:360],T[:,:,0:339]),2)
	Tmean = nc.variables["ARGO_TEMPERATURE_MEAN"][:,2:131,:]
	Tmean = np.concatenate((Tmean[:,:,340:361],Tmean[:,:,0:340]),2)
	nc.close()

	iz=24
	S=T[:,iz,:,:]
	del T
	xx,yy=np.meshgrid(lon, lat)
	#time=nc.variables["TIME"][:] + 0.5
	#plt.figure(1)
	#plt.contourf(lon,lat,S[1,1,:,:])
	#plt.show()

	# target_nc = "RG_ArgoClim_Pden.nc"
	# nc = netcdf.Dataset(target_nc)
	# D=nc.variables["ARGO_DENSITY_ANOMALY"][mt1,:,2:131,:]
	# Dmean = nc.variables["ARGO_DENSITY_MEAN"][:,2:131,:]
	# D = np.concatenate((D[:,:,340:361],D[:,:,0:340]),2)
	# Dmean = np.concatenate((Dmean[:,:,340:361],Dmean[:,:,0:340]),2).astype(float)
	# D = D+Dmean
	# D.lon=nc.variables["LONGITUDE"][:].data-20
	# D.lat=nc.variables["LATITUDE"][2:131].data
	# nc.close()


	target_nc = fdir+"sst.mnmean.nc"
	#nc.variables["time"]
	nc = netcdf.Dataset(target_nc)
	ST=nc.variables["ssta"][mt2,26:155,:]
	ST.lon=nc.variables["lon"][:]
	ST.lat=nc.variables["lat"][26:155]
	nc.close()


	#norm = matplotlib.colors.Normalize(vmin=0, vmax=2)
	#plt.imshow(SH.data[1,:,:],norm=norm)
	#plt.colorbar()
	#plt.show()

	target_nc = fdir+"zos_AVISO_L4_199210-201012.nc"
	nc = netcdf.Dataset(target_nc)
	SH =nc.variables["zosa"][mt3,26:155,:]
	#SH.time=[timedelta(time[ii])+datetime(1950,1,1) for ii in range(1,len(time))]
	SH.lon=nc.variables["lon"][:]
	SH.lat=nc.variables["lat"][26:155]
	nc.close()

	# #
	#target_nc = "D:/02-Data/CCMPv2_monthly/CCMP_Wind_Analysis_200*01_V02.0_L3.5_RSS.nc" 
	# target_nc = "D:/02-Data/CCMPv2_monthly/2000s/*.nc" 
	# nc = netcdf.MFDataset(target_nc,aggdim='time')
	# f  = nn.AvgPool2d(4,4)
	# #utmp = nc.variables["uwnd"][:,63:-52:4,2:-1:4]
	# wlat = nc.variables["latitude"][:]
	# wmin = np.min(np.where(wlat>=-64))-2
	# wmax = np.max(np.where(wlat<=64))+3
	# utmp = nc.variables["uwnd"][mt4,wmin:wmax,:]
	# vtmp = nc.variables["vwnd"][mt4,wmin:wmax,:]
	# wlon = nc.variables["longitude"][:]
	# nc.close()

	# SU = f(torch.from_numpy(utmp)).detach().numpy()
	# SV = f(torch.from_numpy(vtmp)).detach().numpy()

	# SUc = np.zeros((12,SU.shape[1],SU.shape[2]))
	# SVc = np.zeros((12,SU.shape[1],SU.shape[2]))
	# for it in range(0,11):
	#     SUc[it]=np.mean(SU[it:-1:12])
	#     SVc[it]=np.mean(SV[it:-1:12])
	# SUc = np.tile(SUc,(11,1,1))
	# SVc = np.tile(SVc,(11,1,1))
	# SUa = SU - SUc
	# SVa = SV - SVc
	#time =nc.variables["time"][:] + ( (datetime(2001,1,1) - datetime(1900,1,1)).total_seconds()/86400)
	# domain = np.meshgrid(lon,lat)
	# dx, dy = domain
	# dxy = np.stack((dx.flat,dy.flat),axis=1)
	# #dxy = np.squeeze([dx.reshape((dx.size,1)),dy.reshape(dy.size,1)])
	# #ip=scipy.interpolate.RectSphereBivariateSpline(dx,dy,utmp)
	# udata=utmp.reshape(utmp.size,1)
	# [d1,d2] = np.meshgrid(SH.lon.data.reshape(-1,1), SH.lat.data.reshape(-1,1))
	#grid_z0 = griddata(dxy,udata, (d1,d2), method='linear')
	#interp2d(dx,dy,udata,SH.lon.data,SH.lat.data)