# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 21:13:58 2025

@author: Yang
"""
import time
import torch
from collections import defaultdict

class Profiler:
    """
    一个简单的分析器，用于测量代码块的执行时间，特别适用于PyTorch训练循环。
    它使用上下文管理器（'with'语句）来计时，并能处理GPU同步。

    使用方法:
    profiler = Profiler()
    
    for epoch in range(epochs):
        for data in loader:
            with profiler.profile("data_loading"):
                # 数据加载和预处理代码
                ...
            
            with profiler.profile("forward_pass"):
                # 前向传播
                ...

            with profiler.profile("backward_pass"):
                # 后向传播
                ...
        
        profiler.report() # 打印这个epoch的计时报告
        profiler.reset()  # 为下一个epoch重置计时器
    """
    def __init__(self, device):
        self.timings = defaultdict(float)
        self.counts = defaultdict(int)
        self.device = device
        self.start_time = None
        self.current_name = None

    def profile(self, name):
        """返回一个上下文管理器来计时一个代码块。"""
        self.current_name = name
        return self

    def __enter__(self):
        if self.device.type == 'cuda':
            torch.cuda.synchronize()
        self.start_time = time.perf_counter()

    def __exit__(self, type, value, traceback):
        if self.device.type == 'cuda':
            torch.cuda.synchronize()
        duration = time.perf_counter() - self.start_time
        
        self.timings[self.current_name] += duration
        self.counts[self.current_name] += 1

    def reset(self):
        """重置所有计时器。"""
        self.timings = defaultdict(float)
        self.counts = defaultdict(int)

    def report(self):
        """打印所有计时器的汇总报告。"""
        print("\n--- Profiler Report ---")
        if not self.timings:
            print("No timings recorded.")
            return
            
        # 确保total_iteration_time是所有其他时间之和
        total_iteration_time = sum(self.timings.values())
        avg_total_iteration_time = total_iteration_time / next(iter(self.counts.values())) # 用第一个计数器作为总迭代次数

        print(f"Total iterations: {next(iter(self.counts.values()))}")
        print(f"Avg time per iteration: {avg_total_iteration_time:.4f}s")
        print("----------------------------------------")
        
        sorted_timings = sorted(self.timings.items(), key=lambda item: item[1], reverse=True)
        
        for name, total_duration in sorted_timings:
            count = self.counts[name]
            avg_duration = total_duration / count
            percentage = (total_duration / total_iteration_time) * 100 if total_iteration_time > 0 else 0
            print(f"- {name:<20}: "
                  f"Avg: {avg_duration:.4f}s | "
                  f"Total: {total_duration:.2f}s | "
                  f"Percentage: {percentage:.2f}%")
        print("----------------------------------------\n")