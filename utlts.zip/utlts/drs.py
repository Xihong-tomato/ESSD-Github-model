import netCDF4 as netcdf
import numpy as np
#from matplotlib.pyplot import *
#import pandas as pd
import torch.nn as nn
import torch
from datetime import datetime,timedelta
import scipy.io as sio
import os
import utlts.sw as sw
from scipy import signal,interpolate
import h5py
from utlts.U import slice_2Dmatrix

def normalize(v, *argv):
    if len(argv)>1:
        mean = argv[0]
        std = argv[1]
        #print('normalize with ',mean, std)
    else:
        mean = np.nanmean(v)
        std  = np.nanstd(v)
    normalized_v = (v-mean) / std
    return normalized_v

def make_input(xx,yy, *features, lag = 1, ix=slice(0,321,1),iy=slice(250,761,1),segment = 0, if_normal=1,image_size=128,overlap=64):
    #SH,ST,SU,SV,SC
    number_of_features = len(features)
    #print(number_of_features)
    H =(ix.stop-ix.start)//ix.step
    W =(iy.stop-iy.start)//iy.step
    if lag>0:
        train_start=max(1,lag)
        skp = 1
        Nt= features[0].shape[0]
        smp = int((Nt-train_start)/skp)
    elif lag==0:
        smp = features[0].shape[0]
    
    X = np.zeros((smp,number_of_features*(lag+1)+2,H,W))
    
    x66=normalize(np.cos(torch.from_numpy(np.expand_dims(xx[ix,iy],0))/360*2*np.pi))
    x77=normalize(torch.from_numpy(np.expand_dims(yy[ix,iy],0)))
    x66=torch.from_numpy(np.expand_dims(x66,axis=0))
    x77=torch.from_numpy(np.expand_dims(x77,axis=0))
    
    if lag>0:
        for iv in range(train_start,smp+lag):
                
            tmp=np.expand_dims(features[0][iv-lag:iv+1,ix,iy],0)
            for iff in range(1,number_of_features):
                tmp2= np.expand_dims(features[iff][iv-lag:iv+1,ix,iy],0)
                tmp = np.concatenate((tmp,tmp2),1)
                #print(tmp.shape)
                #X[int((iv-train_start)/skp)] =np.squeeze(np.concatenate((x1,x2,x3,x4,x5,x6,x7),1))
            
            X[int((iv-train_start)/skp)] =np.concatenate((x66,x77,tmp),1)
            #print(iv,int((iv-train_start)/skp))
    elif lag==0:
        
        tmp=np.expand_dims(features[0][:,ix,iy],1)
        for iff in range(1,number_of_features):
            tmp2= np.expand_dims(features[iff][:,ix,iy],1)
            tmp = np.concatenate((tmp,tmp2),1)
        x66=np.tile(x66,[tmp.shape[0],1,1,1])
        x77=np.tile(x77,[tmp.shape[0],1,1,1])
        X =np.concatenate((x66,x77,tmp),axis=1)
    #
    if if_normal: #=1 for default
        for ifeature in range(0,X.shape[1]):
            X[:,ifeature] = normalize(X[:,ifeature])
    
    if segment:
        Xc=[]
        for sample in range(X.shape[0]):
            Xtmp = np.moveaxis(X[sample],0,2)
            patch= slice_2Dmatrix(Xtmp, [image_size,image_size],[overlap,overlap])
            Xc+=patch
        X = np.moveaxis(np.asarray(Xc),3,1)
    
    X = torch.from_numpy(X).float()
    

    #make sure X size = [sample, features]
    return X

def make_output(*features,lag = 1, ix=slice(0,321,1),iy=slice(250,761,1),segment = 0, if_normal=1,image_size=128,overlap=64):
    H =(ix.stop-ix.start)//ix.step
    W =(iy.stop-iy.start)//iy.step
    number_of_features = len(features)
    #print(number_of_features)
    if lag>0:
        train_start=max(1,lag)
        skp = 1
        Nt= features[0].shape[0]
        smp = int((Nt-train_start)/skp)
    elif lag==0:
        smp = features[0].shape[0]
    
   
    if lag>0:
        Y = np.zeros((smp,number_of_features,H,W))
        Y_lag = np.zeros((smp,number_of_features*lag,H,W))
        for iv in range(train_start,smp+lag):
            tmp =np.expand_dims(features[0][iv-lag:iv,ix,iy],0)
            tmp3=np.expand_dims(features[0][iv,ix,iy],0)
            for iff in range(1,number_of_features):
                tmp2= np.expand_dims(features[iff][iv-lag:iv,ix,iy],0)
                tmp = np.concatenate((tmp,tmp2),1)
                tmp4= np.expand_dims(features[iff][iv,ix,iy],0)
                tmp3=np.concatenate((tmp3,tmp4),0)
                
            #print(tmp3.shape)
            Y[int((iv-train_start)/skp)]     = tmp3
            Y_lag[int((iv-train_start)/skp)] = np.concatenate((tmp),1)
                
    elif lag==0:
        #Y=np.expand_dims(features[0][:,ix,iy],1)
        Y = np.zeros((number_of_features,smp,H,W))
        for iff in range(0,number_of_features):
            #tmp4= np.expand_dims(features[iff][:,ix,iy],1)
            #Y=np.concatenate((Y,tmp4),1)
            tmp = np.expand_dims(np.squeeze(features[iff][:,ix,iy]),0)
            #print(iff,tmp.shape)
            Y[iff] = tmp
        
        Y=np.moveaxis(Y,0,1)
    
    detrend = 0
    if detrend:
        #X=signal.detrend(X,0)
        Ym=np.mean(Y,0)
        Y=signal.detrend(Y,0)
        Y=Y+Ym
    #
    m=np.zeros((Y.shape[1]))
    s=np.zeros((Y.shape[1]))

    if if_normal:
        for ifeature in range(0,Y.shape[1]):
            m[ifeature] = np.nanmean(Y[:,ifeature])
            s[ifeature] = np.nanstd(Y[:,ifeature])
            Y[:,ifeature] = normalize(Y[:,ifeature])
            if lag>0:
                Y_lag[:,ifeature]=normalize(Y_lag[:,ifeature],m[ifeature],s[ifeature])
    else:
        for ifeature in range(0,Y.shape[1]):
            m[ifeature] = 0
            s[ifeature] = 1
    
    if segment:
        Yc=[]
        YLc=[]
        for sample in range(Y.shape[0]):
            Ytmp = np.moveaxis(Y[sample],0,2)
            patch= slice_2Dmatrix(Ytmp, [image_size,image_size],[overlap,overlap])
            Yc+=patch
            if lag>0:
                Yltmp = np.moveaxis(Y_lag[sample],0,2)
                patch_lag= slice_2Dmatrix(Yltmp, [image_size,image_size],[overlap,overlap])
                YLc+=patch_lag
        Y = np.moveaxis(np.asarray(Yc),3,1)
        if lag>0:
            Y_lag=np.moveaxis(np.asarray(YLc),3,1)
        
    Y = torch.from_numpy(Y).float()
    if lag>0:
        Y_lag=torch.from_numpy(Y_lag).float()
    else:
        Y_lag=None
    #make sure X size = [sample, features]
    
    return Y,Y_lag,m,s



def make_input_lstm(X,Y, tw = 12):
    inout_seq = []
    L = len(X)
    for i in range(L-tw):
        train_seq = X[i:i+tw]
        train_label = Y[i+tw:i+tw+1]
        inout_seq.append((train_seq ,train_label))
    return inout_seq



def OrgX(data,N):
    #organize data so that the size of data matches N
    if N/data.size % 1:
        raise NameError('Wrong Length!')
    D234=np.array((N/data.size),dtype=np.int) # 
    x1=np.tile(np.reshape(np.squeeze(data),(-1,1),order='F'),(D234,1))
    if x1.shape[-1]!=1:
        x1=x1.tranpose()    
    return x1

def unOrgY(data,m1,m2,shape):
    #unorganize data so that the size of data matches N
    Y0 = np.zeros(shape)*np.nan
    for i in range(0,len(m2)):
        if len(shape)==3:
            Y0[:,m1[i],m2[i]] = data[i*0:i*0+58]
        else:
            Y0[:,:,m1[i],m2[i]] = data[i*0:i*0+58]
    return Y0

def normalize(v):
    normalized_v = (v-v.mean()) / v.std()
    return normalized_v
    


def import_data(iz): # for RS and Argo data
    fdir=r'D:/03-Working/DRS/'
    target_nc = fdir+"RG_ArgoClim_Psal.nc"
    nc = netcdf.Dataset(target_nc)
    startDate = datetime(1999,11,1); endDate= datetime(2014,11,30); 
    time=pd.date_range(startDate,endDate,freq='M')+timedelta(1)-datetime(1900,1,1)
    t1=np.asarray([time[ii].total_seconds()/86400 for ii in range(1,len(time))])
    nc.close()

    target_nc = fdir+"sst.mnmean.nc"
    #nc.variables["time"]
    nc = netcdf.Dataset(target_nc)
    time=nc.variables["time"][:].data - 36524
    #ST.time=[timedelta(time[ii])+datetime(1800,1,1) for ii in range(1,len(time))]
    t2=time.tolist()  #1800,1,1 to 1900,1,1
    nc.close()


    target_nc = fdir+"zos_AVISO_L4_199210-201012.nc"
    nc = netcdf.Dataset(target_nc)
    time =nc.variables["time"][:].data + ( (datetime(1950,1,1) - datetime(1900,1,1)).total_seconds()/86400)
    #SH.time=[timedelta(time[ii])+datetime(1950,1,1) for ii in range(1,len(time))]
    t3 = time.tolist()
    nc.close()
    
    # target_nc = "D:/02-Data/CCMPv2_monthly/2000s/*.nc" 
    # nc = netcdf.MFDataset(target_nc,aggdim='time')
    # t4 = nc.variables["time"][:]/24 + ( (datetime(1987,1,1) - datetime(1900,1,1)).total_seconds()/86400)
    # nc.close()

    ccmp=sio.loadmat(r'D:\03-Working\AL\RS_data\CCMP1987-2017-1degree.mat')
    t4=ccmp['time'].transpose() - 693962
    #t4=t4.transplose()
    tmin=max([min(t1),min(t2),min(t3),min(t4)])
    tmax=min([max(t1),max(t2),max(t3),max(t4)])

    #mt1=np.where((np.array(t1)>=tmin) & (np.array(t1)<=tmax))
    #mt2=np.where((np.array(t2)>=tmin) & (np.array(t2)<=tmax))
    #mt3=np.where((np.array(t3)>=tmin) & (np.array(t3)<=tmax))

    mt1=np.intersect1d(np.where(np.array(t1)>=tmin),np.where(np.array(t1)<=tmax))
    mt2=np.intersect1d(np.where(np.array(t2)>=tmin),np.where(np.array(t2)<=tmax))
    mt3=np.intersect1d(np.where(np.array(t3)>=tmin),np.where(np.array(t3)<=tmax))
    mt4=np.intersect1d(np.where(np.array(t4)>=tmin),np.where(np.array(t4)<=tmax))
    mt1=mt1[:]
    mt2=mt2[:]
    mt3=mt3[:] #0:12
    mt4=mt4[1:] #0:12


    target_nc = fdir+"RG_ArgoClim_Psal.nc"
    nc = netcdf.Dataset(target_nc)
    lon=nc.variables["LONGITUDE"][:].data-20
    lat=nc.variables["LATITUDE"][:130].data
    z = nc.variables["PRESSURE"][:].data.reshape(-1,1)
    nc.close()

    target_nc = fdir+"RG_ArgoClim_Psal.nc"
    nc = netcdf.Dataset(target_nc)
    S=nc.variables["ARGO_SALINITY_ANOMALY"][mt1,:,:130,:]
    S=np.concatenate((S[:,:,:,340:],S[:,:,:,:340]),3)
    Smean = nc.variables["ARGO_SALINITY_MEAN"][:,:130,:]
    Smean = np.concatenate((Smean[:,:,340:],Smean[:,:,:340]),2)
    S=S+Smean
    SS=S[:,0]
    nc.close()

    target_nc = fdir+"RG_ArgoClim_Temp.nc"
    nc = netcdf.Dataset(target_nc)
    T=nc.variables["ARGO_TEMPERATURE_ANOMALY"][mt1,:,:130,:]
    T=np.concatenate((T[:,:,:,340:],T[:,:,:,:340]),3)
    Tmean = nc.variables["ARGO_TEMPERATURE_MEAN"][:,:130,:]
    Tmean = np.concatenate((Tmean[:,:,340:],Tmean[:,:,:340]),2)
    T = T + Tmean
    #ST = T[:,0]
    nc.close()


    #time=nc.variables["TIME"][:] + 0.5
    #plt.figure(1)
    #plt.contourf(lon,lat,S[1,1,:,:])
    #plt.show()

    target_nc = fdir+"RG_ArgoClim_Pden.nc"
    nc = netcdf.Dataset(target_nc)
    D=nc.variables["ARGO_DENSITY_ANOMALY"][mt1,:,:130,:].astype(float)
    Dmean = nc.variables["ARGO_DENSITY_MEAN"][:,:130,:].astype(float)
    #D = np.concatenate((D[:,:,340:],D[:,:,:340]),2)
    #Dmean = np.concatenate((Dmean[:,:,340:],Dmean[:,:,:340]),2).astype(float)
    D = D+Dmean
    #D.lon=nc.variables["LONGITUDE"][:].data-20
    #D.lat=nc.variables["LATITUDE"][2:131].data
    nc.close()
    #D[np.isnan(D)]=D.fill_value


    target_nc = fdir+"sst.mnmean.nc"
    #nc.variables["time"]
    nc = netcdf.Dataset(target_nc)
    ST=np.flip(nc.variables["sst"][mt2,25:155,:],1)
    ST.lon=nc.variables["lon"][:]
    ST.lat=nc.variables["lat"][25:155]
    ST.lat=np.flip(ST.lat,0)
    nc.close()


    #norm = matplotlib.colors.Normalize(vmin=0, vmax=2)
    #plt.imshow(SH.data[1,:,:],norm=norm)
    #plt.colorbar()
    #plt.show()

    target_nc = fdir+"zos_AVISO_L4_199210-201012.nc"
    nc = netcdf.Dataset(target_nc)
    SH =nc.variables["zos"][mt3,25:155,:]
    #SH.time=[timedelta(time[ii])+datetime(1950,1,1) for ii in range(1,len(time))]
    SH.lon=nc.variables["lon"][:]
    SH.lat=nc.variables["lat"][25:155]
    nc.close()

    # #
    #target_nc = "D:/02-Data/CCMPv2_monthly/CCMP_Wind_Analysis_200*01_V02.0_L3.5_RSS.nc" 
    # target_nc = "D:/02-Data/CCMPv2_monthly/2000s/*.nc" 
    # nc = netcdf.MFDataset(target_nc,aggdim='time')
    # f  = nn.AvgPool2d(4,4)
    # #utmp = nc.variables["uwnd"][:,63:-52:4,2:-1:4]
    # wlat = nc.variables["latitude"][:]
    # wmin = np.min(np.where(wlat>=-64))-2
    # wmax = np.max(np.where(wlat<=64))+3
    # utmp = nc.variables["uwnd"][mt4,wmin:wmax,:]
    # vtmp = nc.variables["vwnd"][mt4,wmin:wmax,:]
    # wlon = nc.variables["longitude"][:]
    # nc.close()
    SU = ccmp['var1'][mt4]
    SV = ccmp['var2'][mt4]
    SC = ccmp['curl'][mt4]
    #SU = f(torch.from_numpy(utmp)).detach().numpy()
    #SV = f(torch.from_numpy(vtmp)).detach().numpy()
    wind_clim = 0
    if wind_clim:
        SUc = np.zeros((12,SU.shape[1],SU.shape[2]))
        SVc = np.zeros((12,SU.shape[1],SU.shape[2]))
        SCc = np.zeros((12,SU.shape[1],SU.shape[2]))
        for it in range(0,11):
            SUc[it]=np.mean(SU[it:-1:12])
            SVc[it]=np.mean(SV[it:-1:12])
            SCc[it]=np.mean(SC[it:-1:12])
        SUc = np.tile(SUc,(11,1,1))
        SVc = np.tile(SVc,(11,1,1))
        SCc = np.tile(SCc,(11,1,1))
        SUa = SU - SUc
        SVa = SV - SVc
        SCa = SC - SCc
    else:
        SUa = SU - np.mean(SU,0)
        SVa = SV - np.mean(SV,0)
        SCa = SC - np.mean(SC,0)
        
    #S=S
    #S=T
    S = np.squeeze(S[:,:,:,:])
    T = np.squeeze(T[:,:,:,:])
    D = np.squeeze(D[:,:,:,:])
    xx,yy=np.meshgrid(lon, lat)
    #time =nc.variables["time"][:] + ( (datetime(2001,1,1) - datetime(1900,1,1)).total_seconds()/86400)
    # domain = np.meshgrid(lon,lat)
    # dx, dy = domain
    # dxy = np.stack((dx.flat,dy.flat),axis=1)
    # #dxy = np.squeeze([dx.reshape((dx.size,1)),dy.reshape(dy.size,1)])
    # #ip=scipy.interpolate.RectSphereBivariateSpline(dx,dy,utmp)
    # udata=utmp.reshape(utmp.size,1)
    # [d1,d2] = np.meshgrid(SH.lon.data.reshape(-1,1), SH.lat.data.reshape(-1,1))
    #grid_z0 = griddata(dxy,udata, (d1,d2), method='linear')
    S[np.where(S==S.fill_value)]=np.nan
    #interp2d(dx,dy,udata,SH.lon.data,SH.lat.data)
    return S,T,D,SH,ST,SS,SUa,SVa,SCa,xx,yy,z

def import_myocean(iz):
    
    fdir = r'D:/03-Working/DRS/'
    fname= fdir+'MyOceanPO.T.nc'
    f=netcdf.Dataset(fname,'r')
    #f.keys()
    #######if nc file, remember to +1 b'coz it starts from 1!
    T=f.variables['T'][:,:,:,iz]
    #T=T-np.nanmean(T,axis=0)
    ST=f.variables['T'][:,:,:,0]
    f.close()
    
    
    fname= fdir+'MyOceanPO.S.nc'
    f=netcdf.Dataset(fname,'r')
    S=f.variables['S'][:,:,:,iz]#z, 
    SS=f.variables['S'][:,:,:,0]
    f.close()
    # fname= fdir+'MyOceanNPO.uv.mat'
    # f=h5py.File(fname)
    # u=f['u'][:,:,:,:]
    # v=f['v'][:,:,:,:]
    # f.close()
    
    fname= fdir+'MyOceanPO.ssh.mat'
    f=h5py.File(fname,'r')
    SH=f['ssh'][:]
    MLD=f['mld'][:]
    xx=f['x'][:]
    yy=f['y'][:]
    f.close()
    
    fname = fdir+'MyOceanNPO.z.mat'
    f=h5py.File(fname)
    z=f['z'][:].transpose()[0:53]
    f.close()
    
    S=np.moveaxis(S,2,1)
    T=np.moveaxis(T,2,1)
    S=S[:,np.newaxis,:,:]
    T=T[:,np.newaxis,:,:]
    ST=np.moveaxis(ST,1,2)
    SS=np.moveaxis(SS,1,2)
    SH=np.moveaxis(SH,2,0)
    # u=np.moveaxis(u,2,0)
    # v=np.moveaxis(v,2,0)
    MLD=np.moveaxis(MLD,2,0)
    [xx,yy]=np.meshgrid(xx, yy)
    #dimension for S should be
    return S,T,ST,SS,SH,MLD,xx,yy,z

def import_myoceanG(iz):
    
    fdir = r'G:/DRS/'
    fname= fdir+'MyOceanGO.T'+str(iz)+'.mat'
    f=h5py.File(fname,'r')
    T=f['T'][:,:,:]#z, 
    f.close()
    fname= fdir+'MyOceanGO.T0.mat'
    f=h5py.File(fname,'r')
    ST=f['T'][:,:,:]#z, 
    f.close()
    
    fname= fdir+'MyOceanGO.S'+str(iz)+'.mat'
    f=h5py.File(fname,'r')
    S=f['S'][:,:,:]#z, 
    f.close()
    
    fname= fdir+'MyOceanGO.S0.mat'
    f=h5py.File(fname,'r')
    SS=f['S'][:,:,:]#z, 
    f.close()
    
    
    fname= fdir+'MyOceanGO.ssh.mat'
    f=h5py.File(fname,'r')
    SH=f['ssh'][:]
    MLD=f['mld'][:]
    xx=f['x'][:]
    yy=f['y'][:]
    f.close()
    
    fname = fdir+'MyOceanNPO.z.mat'
    f=h5py.File(fname)
    z=f['z'][:].transpose()[0:53]
    f.close()
    
    S=np.moveaxis(S,2,0)
    T=np.moveaxis(T,2,0)
    S=S[:,np.newaxis,:,:]
    T=T[:,np.newaxis,:,:]
    ST=np.moveaxis(ST,2,0)
    SS=np.moveaxis(SS,2,0)
    SH=np.moveaxis(SH,2,0)
    # u=np.moveaxis(u,2,0)
    # v=np.moveaxis(v,2,0)
    MLD=np.moveaxis(MLD,2,0)
    [xx,yy]=np.meshgrid(xx, yy)
    #dimension for S should be [time,1,y,x],others' shoud be [time,y,x]
    return S,T,ST,SS,SH,MLD,xx,yy,z

def import_rs(yyyy=2015,mmm=12):
    fdir = r'D:/02-Data/OISST/OISSTm/'
    fname = fdir+'SST'+str(yyyy)+'m'+format(mmm,'0>2d')+'.mat'
    ST=sio.loadmat(fname)['mvar']
    # fdir = r'D:/02-Data/global-reanalysis-phy-001-025-monthly/all/'
    # fname = fdir+'mercatorglorys2v4_gl4_mean_'+str(yyyy)+format(mmm,'0>2d')+'.nc'
    # f=netcdf.Dataset(fname,'r')
    # #ST=ST*0
    # ST[39:]=f.variables['temperature'][:,0,:,:]
    # ST=np.concatenate((ST[:,720:],ST[:,:720]),1)
    ST[np.where(ST<-100)]=np.nan
    
    
    #SH=np.concatenate((SH[:,720:],SH[:,:720]),1)-0.47 #was 0.5!!
    fdir = r'D:/02-Data/global-reanalysis-phy-001-025-monthly/all/'
    fname = fdir+'mercatorglorys2v4_gl4_mean_'+str(yyyy)+format(mmm,'0>2d')+'.nc'
    f=netcdf.Dataset(fname,'r')
    SH=ST*0
    SH[39:]=f.variables['ssh'][:,:,:]
    SH=np.concatenate((SH[:,720:],SH[:,:720]),1)
    SH[np.where(SH<-100)]=np.nan
    
    fdir = r'D:/02-Data/AVISO_ADT/monthly/'
    fname = fdir+'ADT'+str(yyyy)+'m'+format(mmm,'0>2d')+'.mat'
    SHa=sio.loadmat(fname)['mvar']
    
    tmpx=SH.reshape(1440*720)
    tmpy=SHa.reshape(1440*720)
    mask=np.where(~np.isnan(tmpx+tmpy))
    tmpx=tmpx[mask]
    tmpy=tmpy[mask]
    
    delta=np.nanmean(tmpy)-np.nanmean(tmpx)
    SH=SHa-delta
        
    
    fdir = r'D:/02-Data/global-reanalysis-phy-001-025-monthly/all/'
    fname = fdir+'mercatorglorys2v4_gl4_mean_'+str(yyyy)+format(mmm,'0>2d')+'.nc'
    f=netcdf.Dataset(fname,'r')
    SS=ST*0
    SS[39:]=f.variables['salinity'][:,0,:,:]
    SS=np.concatenate((SS[:,720:],SS[:,:720]),1)
    
    fname = r'D:/02-Data/OISST/OISSTm/lonlat.mat'
    xx=sio.loadmat(fname)['xx']
    yy=sio.loadmat(fname)['yy']
    xx=swich_position(xx)
    yy=swich_position(yy)
    
    ST=swich_position(ST)
    SH=swich_position(SH)
    SS=SS[:-1,:-1]
    
    # ST=ST.transpose()
    # SH=SH.transpose()
    # SS=SS.transpose()
    # xx=xx.transpose()
    # yy=yy.transpose()
    return ST,SH,SS,xx,yy

def swich_position(a):
    a=(a[:,:-1]+a[:,1:])/2
    a=(a[:-1]+a[1:])/2
    return a
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    