# -*- coding: utf-8 -*-
"""
@author: Yang
"""

import torch

class CudaStreamPrefetcher:
    """
    通过区分cuda stream以预取数据, 从而加速训练过程。
    允许数据传输与模型计算重叠！
    在模型推理的时候，可以提前准备好数据。
    一旦模型结束当前批次的计算, 下一批数据已经在GPU上准备好了。(不需要再次等待to.device的数据搬运过程)
    """
    def __init__(self, loader, device):
        self.loader = iter(loader)
        self.device = device
        self.stream = torch.cuda.Stream()
        # 预加载第一批数据
        self.preload()

    def preload(self):
        try:
            # 从 dataloader 获取下一批数据 (在CPU上)
            self.next_batch = next(self.loader)
        except StopIteration:
            self.next_batch = None
            return

        # 将数据异步传输到GPU
        with torch.cuda.stream(self.stream):
            self.next_batch = [
                tensor.to(self.device, non_blocking=True) if torch.is_tensor(tensor) else tensor 
                for tensor in self.next_batch
            ]

    def __next__(self):
        # 等待当前预取流上的数据传输完成
        torch.cuda.current_stream().wait_stream(self.stream)
        if self.next_batch is None:
            raise StopIteration
        # 获取已准备好的数据
        batch = self.next_batch
        # 开始预加载下一批数据
        self.preload()
        
        return batch

    def __iter__(self):
        return self