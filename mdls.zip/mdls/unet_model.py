""" Full assembly of the parts to form the complete network """

import torch.nn.functional as F

from .unet_parts import *

class UNet_ygy(nn.Module):
    def __init__(self, n_channels, n_classes, bilinear=True):
        super(UNet_ygy, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear

        self.inc = DoubleConv(n_channels, 32)
        self.down1 = DownCC(32, 64)
        self.down2 = DownCC(64, 128)
        self.down3 = DownCC(128, 256)
        self.down4 = DownCC(256, 512)
        self.up1 = Up(256 + 512, 256, bilinear)
        self.up2 = Up(128 + 256, 128, bilinear)
        self.up3 = Up(64 + 128, 64, bilinear)
        self.up4 = Up(64 + 32, 32, bilinear)
        self.outc = OutConv(32, n_classes)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)       
        x = self.up4(x, x1)
        logits = self.outc(x)
        return logits

class UNet(nn.Module):
    def __init__(self, n_channels, n_classes, bilinear=True):
        super(UNet, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear

        self.inc = DoubleConv(n_channels, 32)
        self.down1 = Down(32, 64)
        self.down2 = Down(64, 128)
        self.down3 = Down(128, 256)
        self.down4 = Down(256, 512)
        self.up1 = Up(256 + 512, 256, bilinear)
        self.up2 = Up(128 + 256, 128, bilinear)
        self.up3 = Up(64 + 128, 64, bilinear)
        self.up4 = Up(64 + 32, 32, bilinear)
        self.outc = OutConv(32, n_classes)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)       
        x = self.up4(x, x1)
        logits = self.outc(x)
        return logits


class UNet_small(nn.Module):
    def __init__(self, n_channels, n_classes, bilinear=True):
        super(UNet_small, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear

        self.inc = DoubleConv(n_channels, 32)
        self.down1 = Down(32, 64)
        self.down2 = Down(64, 128)
        self.down3 = Down(128, 256)
        self.down4 = Down(256, 512)
        self.up1 = Up(512+256, 256, bilinear)
        self.up2 = Up(128+256, 128, bilinear)
        self.up3 = Up(64+128, 64, bilinear) 
        self.up4 = Up(64+32, 32, bilinear)
        self.outc = OutConv(32, n_classes)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        #print(x5.shape)
        #print(x4.shape)
        x = self.up1(x5,x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)    
        x = self.up4(x, x1)
        logits = self.outc(x)
        return logits