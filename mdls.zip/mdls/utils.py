import pandas as pd
import netCDF4 as nc
import os
import numpy as np
import random
import torch
from torch.utils.data import Dataset
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import xarray as xr

def adjust_learning_rate(lr, optimizer, epoch, lr_changestep):
    """Sets the learning rate to the initial LR decayed by 10 every args.step epochs"""
    if epoch > 1:
        lr = lr * (0.9 ** (epoch // lr_changestep))
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
    return lr

def coreff(x, y):
    x_mean = np.mean(x)
    y_mean = np.mean(y)
    c1 = sum((x - x_mean) * (y - y_mean))
    c2 = sum((x - x_mean) ** 2) * sum((y - y_mean) ** 2)
    return c1 / np.sqrt(c2)


def rmse(preds, y):
    return np.sqrt(sum((preds - y) ** 2) / preds.shape[0])


def eval_score(preds, label):
    # preds = preds.cpu().detach().numpy().squeeze()
    # label = label.cpu().detach().numpy().squeeze()
    acskill = 0
    RMSE = 0
    a = [1.5] * 4 + [2] * 7 + [3] * 7 + [4] * 6
    for i in range(24):
        RMSE += rmse(label[:, i], preds[:, i])
        cor = coreff(label[:, i], preds[:, i])
        acskill += a[i] * np.log(i + 1) * cor
    return 2 / 3 * acskill - RMSE

# def series_to_superised_in_2d(var2superised, n_in, n_out):
#     nsteps = var2superised.shape[0]
#     nlat = var2superised.shape[1]
#     nlon = var2superised.shape[2]
#     ncols = int(nsteps - n_out - n_in - 1)  # lower bound are 0 .
#     train_cols = []  # np.zeros((ncols, 12), dtype = int)
#     for ii in range(ncols):
#         if ii == 0:
#             #colTemp = np.linspace(0, n_in - 1, n_in)
#             colTemp = np.linspace(0, n_in - 1, n_in)
#             train_cols.append([int(_) for _ in colTemp])
#         else:
#             colTemp = colTemp + 1
#             train_cols.append([int(_) for _ in colTemp])
#     resAll_in = np.zeros((ncols, n_in, nlat, nlon), dtype=float)
#     for ii in range(ncols):
#         resAll_in[ii, :, :, :] = var2superised[np.asarray(train_cols[ii]), :, :]
#     return resAll_in
#
# def series_to_superised_inOut_2d(var2superised, n_in, n_out):
#     nsteps = var2superised.shape[0]
#     nlat = var2superised.shape[1]
#     nlon = var2superised.shape[2]
#     nt = n_in
#     ncols = int(nsteps - n_in - 1)  # lower bound are 0 .
#     train_cols = []  # np.zeros((ncols, 12), dtype = int)
#     for ii in range(ncols):
#         if ii == 0:
#             #colTemp = np.linspace(0, n_in - 1, n_in)
#             colTemp = np.linspace(0, nt - 1, nt)
#             train_cols.append([int(_) for _ in colTemp])
#         else:
#             colTemp = colTemp + 1
#             train_cols.append([int(_) for _ in colTemp])
#     resAll_in = np.zeros((ncols, nt, nlat, nlon), dtype=float)
#     for ii in range(ncols):
#         resAll_in[ii, :, :, :] = var2superised[np.asarray(train_cols[ii]), :, :]
#     return resAll_in
#
#
# def series_to_superised_out_2d(var2superised, n_in, n_out):
#     nsteps = var2superised.shape[0]
#     nlat = var2superised.shape[1]
#     nlon = var2superised.shape[2]
#     ncols = int(nsteps - n_out - n_in)  # lower bound are 0 .
#     train_cols = []  # np.zeros((ncols, 12), dtype = int)
#     for ii in range(ncols):
#         if ii == 0:
#             colTemp = np.linspace(n_in, n_in + n_out - 1, n_out)
#             train_cols.append([int(_) for _ in colTemp])
#         else:
#             colTemp = colTemp + 1
#             train_cols.append([int(_) for _ in colTemp])
#     resAll_out = np.zeros((ncols, n_out, nlat, nlon), dtype=float)
#     for ii in range(ncols):
#         resAll_out[ii, :, :, :] = var2superised[np.asarray(train_cols[ii]), :, :]
#     return resAll_out

def series_to_superised_out_2d(var2superised, n_in, n_out):
    nsteps = var2superised.shape[0]
    nlat = var2superised.shape[1]
    nlon = var2superised.shape[2]
    ncols = int(nsteps - n_out - n_in)  # lower bound are 0 .
    train_cols = []  # np.zeros((ncols, 12), dtype = int)
    for ii in range(ncols):
        if ii == 0:
            colTemp = np.linspace(n_in, n_in + n_out - 1, n_out)
            train_cols.append([int(_) for _ in colTemp])
        else:
            colTemp = colTemp + 1
            train_cols.append([int(_) for _ in colTemp])
    resAll_out = np.zeros((ncols, n_out, nlat, nlon), dtype=float)
    for ii in range(ncols):
        resAll_out[ii, :, :, :] = var2superised[np.asarray(train_cols[ii]), :, :]
    return resAll_out

def series_to_superised_inOut_2d(var2superised, n_in, n_out):
    nsteps = var2superised.shape[0]
    nlat = var2superised.shape[1]
    nlon = var2superised.shape[2]
    nt = n_in
    ncols = int(nsteps - n_out - n_in )  # lower bound are 0 .
    train_cols = []  # np.zeros((ncols, 12), dtype = int)
    for ii in range(ncols):
        if ii == 0:
            #colTemp = np.linspace(0, n_in - 1, n_in)
            colTemp = np.linspace(0, nt - 1, nt)
            train_cols.append([int(_) for _ in colTemp])
        else:
            colTemp = colTemp + 1
            train_cols.append([int(_) for _ in colTemp])
    resAll_in = np.zeros((ncols, nt, nlat, nlon), dtype=float)
    for ii in range(ncols):
        resAll_in[ii, :, :, :] = var2superised[np.asarray(train_cols[ii]), :, :]
    return resAll_in


def scalerMeanStd(datain, maskr):
    scaler = StandardScaler()
    ndim0, ndim1, ndim2 = datain.shape
    _datain = datain.reshape(ndim0, ndim1 * ndim2)
    _maskr = np.tile(maskr.reshape(1, ndim1 * ndim2), [ndim0, 1])
    _datain0 = _datain[_maskr>0.5]
    scaler.fit(_datain0.reshape(-1, 1))
    dataMean = scaler.mean_
    dataStd = scaler.var_
    _dataout = (_datain - dataMean)/dataStd
    #_dataout[_maskr<0.5] = 0
    dataout = _dataout.reshape(ndim0, ndim1, ndim2)
    return dataout, [dataMean, dataStd]

def scalerData(datain):
    scaler = StandardScaler()
    ndim0, ndim1, ndim2 = datain.shape
    _datain = datain.reshape(ndim0, ndim1 * ndim2)
    scaler.fit(_datain)
    _datain = scaler.transform(_datain)
    dataout = _datain.reshape(ndim0, ndim1, ndim2)
    return dataout, scaler

def scalerDataMinMax(datain):
    scaler = MinMaxScaler(feature_range=(0, 1))
    ndim0, ndim1, ndim2, ndim3 = datain.shape
    _datain = datain.reshape(ndim0 * ndim1, ndim2 * ndim3)
    scaler.fit(_datain)
    _datain = scaler.transform(_datain)
    dataout = _datain.reshape(ndim0, ndim1, ndim2, ndim3)
    return dataout

def getWaveScaler(swanfile, maskr):
    ds = xr.open_dataset(swanfile, chunks={'time': 12})
    wx = np.array(ds.wx[:, :, :])
    wy = np.array(ds.wy[:, :, :])
    hs = np.array(ds.hs[:, :, :])
    # data normalization
    _, scalerWx = scalerMeanStd(wx, maskr)
    _, scalerWy = scalerMeanStd(wy, maskr)
    _, scalerHs = scalerMeanStd(hs, maskr)

    return scalerWx, scalerWy, scalerHs

def pre_era5_data(ds, n_in, n_out):

    # ds = xr.open_dataset(era5file)

    u10 = ds.u10[:].data  # .to_numpy()
    v10 = ds.v10[:].data
    mwd = ds.mwd[:].data
    mwp = ds.mwp[:].data
    swh = ds.swh[:].data
    maskr = np.isnan(swh)
    u10[maskr] = 0
    v10[maskr] = 0
    mwd[maskr] = 0
    mwp[maskr] = 0
    swh[maskr] = 0

    nx1d = u10.shape[-1]
    ny1d = u10.shape[-2]

    _hs_out = series_to_superised_out_2d(swh, n_in, n_out)
    _mwp_out = series_to_superised_out_2d(mwp, n_in, n_out)
    _mwd_out = series_to_superised_out_2d(mwd, n_in, n_out)

    ncols = _hs_out.shape[0]
    resAll_out = np.zeros((ncols, n_out, 3, ny1d, nx1d), dtype=float)
    resAll_out[:, :, 0, :, :] = _hs_out
    resAll_out[:, :, 1, :, :] = _mwp_out
    resAll_out[:, :, 2, :, :] = _mwd_out
    resAll_in = np.zeros((ncols, n_in, 2, ny1d, nx1d), dtype=float)
    resAll_in[:, :, 0, :, :] = series_to_superised_inOut_2d(u10, n_in, n_out)
    resAll_in[:, :, 1, :, :] = series_to_superised_inOut_2d(v10, n_in, n_out)

    return resAll_in, resAll_out

def pre_era5_data_npy(year, n_in, n_out):

    # ds = xr.open_dataset(era5file)
    u10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyFromGlobal\%04d\u10Land0_%04d.npy"%(year, year), allow_pickle=True)
    v10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyFromGlobal\%04d\v10Land0_%04d.npy" % (year, year), allow_pickle=True)
    mwd = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyFromGlobal\%04d\mwd%04d.npy" % (year, year), allow_pickle=True)
    mwp = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyFromGlobal\%04d\mwp%04d.npy" % (year, year), allow_pickle=True)
    swh = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyFromGlobal\%04d\swh%04d.npy" % (year, year), allow_pickle=True)

    swhMin = 0
    swhMax = 18.37

    nx1d = u10.shape[-1]
    ny1d = u10.shape[-2]

    _hs_out = series_to_superised_out_2d(swh, n_in, n_out)
    _mwp_out = series_to_superised_out_2d(mwp, n_in, n_out)
    _mwd_out = series_to_superised_out_2d(mwd, n_in, n_out)

    _hs_out = (_hs_out - swhMin)/(swhMax - swhMin)

    ncols = _hs_out.shape[0]
    resAll_out = np.zeros((ncols, n_out, 3, ny1d, nx1d), dtype=float)
    resAll_out[:, :, 0, :, :] = _hs_out
    resAll_out[:, :, 1, :, :] = _mwp_out
    resAll_out[:, :, 2, :, :] = _mwd_out
    resAll_in = np.zeros((ncols, n_in, 2, ny1d, nx1d), dtype=float)
    resAll_in[:, :, 0, :, :] = series_to_superised_inOut_2d(u10, n_in, n_out)
    resAll_in[:, :, 1, :, :] = series_to_superised_inOut_2d(v10, n_in, n_out)

    return resAll_in, resAll_out

def pre_era5_data_npy_scale(year, n_in, n_out):

    # ds = xr.open_dataset(era5file)
    u10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyLandFill\%04d\u10Land0_%04d.npy"%(year, year), allow_pickle=True)
    v10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyLandFill\%04d\v10Land0_%04d.npy" % (year, year), allow_pickle=True)
    # mwd = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyLandFill\%04d\mwd%04d.npy" % (year, year), allow_pickle=True)
    mwp = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyLandFill\%04d\minmax_mwp%04d.npy" % (year, year), allow_pickle=True)
    # swh = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npyLandFill\%04d\mwd%04d.npy" % (year, year), allow_pickle=True)

    nx1d = u10.shape[-1]
    ny1d = u10.shape[-2]

    _hs_out = series_to_superised_out_2d(mwp, n_in, n_out)
    # _mwp_out = series_to_superised_out_2d(mwp, n_in, n_out)
    # _mwd_out = series_to_superised_out_2d(mwd, n_in, n_out)

    # _hs_out = (_hs_out - swhMin)/(swhMax - swhMin)

    ncols = _hs_out.shape[0]
    # resAll_out = np.zeros((ncols, n_out, 3, ny1d, nx1d), dtype=float)
    # resAll_out[:, :, 0, :, :] = _hs_out
    # resAll_out[:, :, 1, :, :] = _mwp_out
    # resAll_out[:, :, 2, :, :] = _mwd_out
    resAll_out = np.zeros((ncols, n_out, ny1d, nx1d), dtype=float)
    resAll_out[:, :, :, :] = _hs_out
    resAll_in = np.zeros((ncols, n_in, 2, ny1d, nx1d), dtype=float)
    resAll_in[:, :, 0, :, :] = series_to_superised_inOut_2d(u10, n_in, n_out)
    resAll_in[:, :, 1, :, :] = series_to_superised_inOut_2d(v10, n_in, n_out)

    return resAll_in, resAll_out

def pre_wave_data(swanfile, maskr, n_in, n_out):
    #ds = xr.open_dataset(swanfile, chunks={'X': 100, 'Y': 100})
    ds = xr.open_dataset(swanfile, chunks={'time': 12})
    wx = np.array(ds.wx[:, :-2, :])
    wy = np.array(ds.wy[:, :-2, :])
    hs = np.array(ds.hs[:, :-2, :])
    #ncfile = nc.Dataset(swanfile, mode='r')
    #wx = np.asarray(ncfile.variables['wx'])[:, :, :]
    #wy = np.asarray(ncfile.variables['wy'])[:, :, :]
    #hs = np.asarray(ncfile.variables['hs'])[:, :, :]

    # data normalization
    _, scalerWx = scalerMeanStd(wx, maskr[:-2, :])
    _, scalerWy = scalerMeanStd(wy, maskr[:-2, :])
    _, scalerHs = scalerMeanStd(hs, maskr[:-2, :])
    # wx, scalerWx = scalerData(wx)
    # wy, scalerWy = scalerData(wy)
    # hs, scalerHs = scalerData(hs)

    #wx = wx[:, :, 52:]
    #wy = wy[:, :, 52:]
    #hs = hs[:, :, 52:]
    nlon = wx.shape[-1]
    nlat = wx.shape[-2]

    resAll_out = series_to_superised_out_2d(hs, n_in, n_out)

    ncols = resAll_out.shape[0]

    resAll_in = np.zeros((ncols, n_in, 2, nlat, nlon), dtype=float)
    resAll_in[:, :, 0, :, :] = series_to_superised_inOut_2d(wx, n_in, n_out)
    resAll_in[:, :, 1, :, :] = series_to_superised_inOut_2d(wy, n_in, n_out)

    return resAll_in, resAll_out, scalerWx, scalerWy, scalerHs



class BasicDataset_SWAN(Dataset):
    def __init__(self, ncfile2read, ds, mask_rho, n_in, n_out):
        self.ncfile = ncfile2read
        self.n_in = n_in
        self.n_out = n_out
        self.ds = ds
        self.maskr = mask_rho
        self.resAll_in, self.resAll_out, self.scalerWx, self.scalerWy,self.scalerHs = \
            pre_wave_data(self.ncfile, self.maskr, self.n_in, self.n_out)
        #self.random = random.Random()

    def __len__(self):
        return self.resAll_out.shape[0]
        #return self.ds.wx.shape[0] - self.n_in + 1

    # def __getitem__(self, i):
    #     # add normailed here todo
    #     #_in = self.resAll_in[i, :, :, :, :]
    #     #_out = self.resAll_out[i, :]
    #
    #     if i < 12:
    #         cols2read = [i]*12
    #     else:
    #         colTemp = np.linspace(i - self.n_in, i - 1 , self.n_in)
    #         cols2read = [int(_) for _ in colTemp]
    #     _in = np.asarray([self.ds.wx[cols2read, :-2, :].to_numpy(),\
    #                      self.ds.wy[cols2read, :-2, :].to_numpy()])
    #     _out = np.asarray(self.ds.hs[i, :-2, :].to_numpy())[np.newaxis, :]
    #     return torch.from_numpy(_in.transpose(1, 0, 2, 3)), \
    #            torch.from_numpy(_out)
    def __getitem__(self, i):
        # add normailed here todo
        _in = self.resAll_in[i, :, :, :, :]
        _out = self.resAll_out[i, :, :, :]
        return torch.from_numpy(_in), \
               torch.from_numpy(_out)

class BasicDataset_ERA5YearlyScale(Dataset):
    def __init__(self, year, n_in, n_out):
        # nx = 71
        # ny = 61
        self.n_in = n_in
        self.n_out = n_out
        # self.indexLon = np.append(0, np.arange(nx))
        # self.indexLat = np.append([0, 0, 0], np.arange(ny))

        self.resAll_in, self.resAll_out = pre_era5_data_npy_scale(year, n_in, n_out)

    def __len__(self):
        return self.resAll_in.shape[0]

    def __getitem__(self, i):
        _in = self.resAll_in[i, :]
        # _out = self.resAll_out[i, :, 0, :]
        _out = self.resAll_out[i, :, :]
        return torch.from_numpy(_in), \
               torch.from_numpy(_out)

class BasicDataset_ERA5Yearly(Dataset):
    def __init__(self, year, n_in, n_out):
        # nx = 71
        # ny = 61
        self.n_in = n_in
        self.n_out = n_out
        # self.indexLon = np.append(0, np.arange(nx))
        # self.indexLat = np.append([0, 0, 0], np.arange(ny))

        self.resAll_in, self.resAll_out = pre_era5_data_npy(year, n_in, n_out)

    def __len__(self):
        return self.resAll_in.shape[0]

    def __getitem__(self, i):
        _in = self.resAll_in[i, :]
        _out = self.resAll_out[i, :, 0, :]
        return torch.from_numpy(_in), \
               torch.from_numpy(_out)
        #return torch.tensor(wind.data.compute()), torch.tensor(hs.data.compute())
        #return torch.asarray(wind.data), torch.asarray(hs.data)
        # return torch.from_numpy(wind.data), torch.from_numpy(wave.data)

class BasicDataset_ERA5OneFile(Dataset):
    def __init__(self, ds):
        self.ds = ds
        nx = ds.X.shape[0]
        ny = ds.Y.shape[0]
        self.indexLon = np.append(0, np.arange(nx))
        self.indexLat = np.append([0, 0, 0], np.arange(ny))

    def __len__(self):
        return self.ds.time.shape[0]

    def __getitem__(self, i):
        wind = self.ds.wind[i, 12:, :, self.indexLat, self.indexLon] #.to_numpy()
        wave = self.ds.wave[i, :12, 0, self.indexLat, self.indexLon] #.to_numpy()

        #return torch.tensor(wind.data.compute()), torch.tensor(hs.data.compute())
        #return torch.asarray(wind.data), torch.asarray(hs.data)
        return torch.from_numpy(wind.data), torch.from_numpy(wave.data)

class BasicDataset_ERA5OneFileHalf(Dataset):
    def __init__(self, ds):
        self.ds = ds
        nx = ds.X.shape[0]
        self.index = np.append(0, np.arange(nx))

    def __len__(self):
        return self.ds.time.shape[0]

    def __getitem__(self, i):
        wind = self.ds.wind[i, :, :, 29:, self.index] #.to_numpy()
        hs =   self.ds.hs  [i, :, 29:, self.index] #.to_numpy()
        #return torch.tensor(wind.data.compute()), torch.tensor(hs.data.compute())
        #return torch.asarray(wind.data), torch.asarray(hs.data)

        return torch.from_numpy(wind.data), torch.from_numpy(hs.data)

class BasicDataset_ERA5OneFileQuarter(Dataset):
    def __init__(self, ds):
        self.ds = ds
        nx = ds.X.shape[0]
        self.index = np.append(0, np.arange(nx))

    def __len__(self):
        return self.ds.time.shape[0]

    def __getitem__(self, i):
        wind = self.ds.wind[i, :, :, 29:, 35:] #.to_numpy()
        hs =   self.ds.hs  [i, :, 29:, 35:] #.to_numpy()
        #return torch.tensor(wind.data.compute()), torch.tensor(hs.data.compute())
        #return torch.asarray(wind.data), torch.asarray(hs.data)

        return torch.from_numpy(wind.data), torch.from_numpy(hs.data)

class BasicDataset_SWAN7YearOneFile(Dataset):
    def __init__(self, ds):
        self.ds = ds

    def __len__(self):
        return self.ds.time.shape[0]

    def __getitem__(self, i):
        wind = self.ds.wind[i, :, :, :-2, :] #.to_numpy()
        hs =   self.ds.hs  [i, :, :-2, :] #.to_numpy()
        #return torch.tensor(wind.data.compute()), torch.tensor(hs.data.compute())
        #return torch.asarray(wind.data), torch.asarray(hs.data)
        try:
            aa = torch.from_numpy(wind.data)
            bb = torch.from_numpy(hs.data)
        except:
            wind = self.ds.wind[10, :, :, :-2, :]
            hs = self.ds.hs[10, :, :-2, :]
            aa = torch.from_numpy(wind.data)
            bb = torch.from_numpy(hs.data)
        return aa, bb

class BasicDataset_SWAN7Year(Dataset):
    def __init__(self, ncfile2read, ds, mask_rho, n_in, n_out):
        self.ncfile = ncfile2read
        self.n_in = n_in
        self.n_out = n_out
        self.ds = ds
        self.maskr = mask_rho
        # self.scalerWx, self.scalerWy,self.scalerHs = \
        #     getWaveScaler(self.ncfile, self.maskr)
        #self.random = random.Random()

    def __len__(self):
        return self.ds.wx.shape[0] - self.n_in + 1

    def __getitem__(self, i):

        if i < 12:
            cols2read = [i]*12
        else:
            colTemp = np.linspace(i - self.n_in, i - 1 , self.n_in)
            cols2read = [int(_) for _ in colTemp]

        wx0 = self.ds.wx[cols2read, :-2, :] #.to_numpy()
        wy0 = self.ds.wy[cols2read, :-2, :] #.to_numpy()
        hs0 = self.ds.hs[i, :-2, :].to_numpy()
        # norm here
        #wx0 = (wx0 - self.scalerWx[0]) / self.scalerWx[1]
        #wy0 = (wy0 - self.scalerWy[0]) / self.scalerWy[1]
        #hs0 = (hs0 - self.scalerHs[0]) / self.scalerHs[1]
        #_maskr = np.tile(self.maskr, [self.n_in, 1, 1])
        #wx0[_maskr < 0.5] = 0
        #wy0[_maskr < 0.5] = 0

        hs0[self.maskr < 0.5] = 0
        _in = np.asarray([wx0, wy0])
        _out = np.asarray(hs0)[np.newaxis, :]

        return torch.from_numpy(_in.transpose(1, 0, 2, 3)), \
               torch.from_numpy(_out)

    # def __getitem__(self, i):
    #     # add normailed here todo
    #     _in = self.resAll_in[i, :, :, :, :]
    #     _out = self.resAll_out[i, :]
    #     return torch.from_numpy(_in), \
    #            torch.from_numpy(_out)

# class BasicDataset_SODA_Data(Dataset):
#     def __init__(self):
#         sodafileTrain = r'd:\oneDrive2020\OneDrive\OceanNotes\tianchi\enso_round1_train_20210201\SODA_train.nc'
#         sodafileLabel = r'd:\oneDrive2020\OneDrive\OceanNotes\tianchi\enso_round1_train_20210201\SODA_label.nc'
#         train = xr.open_dataset(sodafileTrain)
#         label = xr.open_dataset(sodafileLabel)
#         train_sst = train['sst'][:, :12].values  # (4645, 12, 24, 72)
#         train_t300 = train['t300'][:, :12].values
#         train_ua = train['ua'][:, :12].values
#         train_va = train['va'][:, :12].values
#         train_label = label['nino'][:, 12:36].values
#
#         train_ua = np.nan_to_num(train_ua)
#         train_va = np.nan_to_num(train_va)
#         train_t300 = np.nan_to_num(train_t300)
#         train_sst = np.nan_to_num(train_sst)
#
#         train_sst = scalerDataMinMax(train_sst)
#         train_t300 = scalerDataMinMax(train_t300)
#         train_ua = scalerDataMinMax(train_ua)
#         train_va = scalerDataMinMax(train_va)
#
#         _soda_in = np.concatenate((train_sst.reshape(-1, train_sst.shape[0], \
#                                                      train_sst.shape[1], \
#                                                      train_sst.shape[2], \
#                                                      train_sst.shape[3]), \
#                                    train_t300.reshape(-1, train_t300.shape[0], \
#                                                       train_t300.shape[1], \
#                                                       train_t300.shape[2], \
#                                                       train_t300.shape[3]), \
#                                    train_ua.reshape(-1, train_ua.shape[0], \
#                                                     train_ua.shape[1], \
#                                                     train_ua.shape[2], \
#                                                     train_ua.shape[3]), \
#                                    train_va.reshape(-1, train_va.shape[0], \
#                                                     train_va.shape[1], \
#                                                     train_va.shape[2], \
#                                                     train_va.shape[3])), \
#                                   axis=0)
#         # # dim should be timsstep, sequence, nlat, nlon , channel
#         self.sodaRes_in = _soda_in.transpose(1, 2, 3, 4, 0)
#         self.sodaRes_out = train_label
#
#     def __len__(self):
#         return self.sodaRes_out.shape[0]
#
#     def __getitem__(self, i):
#         _in = self.sodaRes_in[i, :, 0:21, 20:60, :]
#         _out = self.sodaRes_out[i, :]
#         # dim are timesteps, 12, channel, nlat, nlon
#         return torch.from_numpy(_in.transpose(0, 3, 1, 2)), \
#                torch.from_numpy(_out)
