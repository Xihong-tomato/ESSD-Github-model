import torch.nn as nn
import torch

class CNN1(nn.Module):
    def __init__(self,shapeX):
        super(CNN1, self).__init__()
        self.conv1 = nn.Sequential(         # input shape (34, 64, 64)
            nn.Conv2d(shapeX,32,(1,1),1,(0,0)),  # output shape (64, 28, 28)
            nn.BatchNorm2d(32),
            #nn.Dropout(0.5),
            nn.ReLU(inplace=True),                      # activation
            #nn.MaxPool2d(1),    # 理论上没效果
            nn.Conv2d(32,64,1,1,0),
            #nn.Dropout(0.5),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            #nn.MaxPool2d(1),    # output shape (64, Y/4, X/4)
            nn.Conv2d(64,64,1,1,0),
            #nn.Dropout(0.5),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            #nn.MaxPool2d(1),    # output shape
            nn.Conv2d(64,64,1,1,0),
            #nn.Dropout(0.3),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64,6,1,1,0),
            #nn.MaxPool2d(1),    # output shape (64, Y/8, X/8)
        )
#         self.fc  = nn.Sequential(
#             nn.Linear(64, 32),
#             #nn.Dropout(0.5),
# 			nn.ReLU(inplace=True),
# 			nn.Linear(32,16),
#             nn.ReLU(inplace=True),
# 			nn.Linear(16,8),
#             nn.ReLU(inplace=True),
# 			nn.Linear(8,4),
#             #nn.Dropout(0.5),
# 			nn.ReLU(inplace=True),
#             nn.Linear(4, 1),
#         )

    def forward(self, x):
        output = self.conv1(x) #+ x[:,:-1]
        #output = self.fc(output)
        #print(output.shape)
        return output   # return x for visualization
		
		
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.fc  = nn.Sequential(
            nn.Linear(2, 256),
            #nn.Dropout(0.5),
			nn.ReLU(),
			nn.Linear(256,256),
            nn.ReLU(),
			nn.Linear(256,256),
            nn.ReLU(),
			nn.Linear(256,256),
            #nn.Dropout(0.5),
			nn.ReLU(),
            nn.Linear(256, 1),
        )

    def forward(self, x):
        output = self.fc(x)
        #print(x.shape)
        return output   # return x for visualization



