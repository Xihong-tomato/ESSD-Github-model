import os
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import Dataset

def adjust_learning_rate(lr, optimizer, epoch, lr_changestep):
    """Sets the learning rate to the initial LR decayed by 10 every args.step epochs"""
    if epoch > 1:
        lr = lr * (0.8 ** (epoch // lr_changestep))
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
    return lr

def pre_era5_data_npy_scale(year, hourModel):

    # ds = xr.open_dataset(era5file)
    # u10 = np.load(r"L:\00AI\dataTrain\ERA5Swell\trainDataTemp\wind\u10Land0_%04d.npy"%( year), allow_pickle=True)
    # v10 = np.load(r"L:\00AI\dataTrain\ERA5Swell\trainDataTemp\wind\v10Land0_%04d.npy" % ( year), allow_pickle=True)
    # mwd = np.load(r"L:\00AI\dataTrain\ERA5Swell\trainDataTemp\allWave\mwdAll_%04d.npy" % ( year), allow_pickle=True)
    # mwp = np.load(r"L:\00AI\dataTrain\ERA5Swell\trainDataTemp\allWave\mwpAll_%04d.npy" % ( year), allow_pickle=True)
    # swh = np.load(r"L:\00AI\dataTrain\ERA5Swell\trainDataTemp\allWave\swhAll_%04d.npy" % ( year), allow_pickle=True)
    u10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\u10Land0_%04d.npy" % (year, year),
                  allow_pickle=True)
    v10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\v10Land0_%04d.npy" % (year, year),
                  allow_pickle=True)
    mwd = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\mwd%04d.npy" % (year, year), allow_pickle=True)
    mwp = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\mwp%04d.npy" % (year, year), allow_pickle=True)
    swh = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\swh%04d.npy" % (year, year), allow_pickle=True)
    nvar_in = 2 + 3 + 2  # initial wind_u wind_v, initial swh, mwp. mwd, target wind_u, wind_v
    nvar_out = 3         # target swh mwp mwd

    resAll_in = []
    resAll_out = []

    for istep in range(u10.shape[0] - hourModel):
        ini_u = u10[istep, :]
        ini_v = v10[istep, :]
        ini_swh = swh[istep, :]
        ini_mwp = mwp[istep, :]
        ini_mwd = mwd[istep, :]
        tar_u = u10[istep + hourModel, :]
        tar_v = v10[istep + hourModel, :]
        res_in = np.concatenate((ini_u[np.newaxis, :],
                                 ini_v[np.newaxis, :],
                                 ini_swh[np.newaxis, :],
                                 ini_mwp[np.newaxis, :],
                                 ini_mwd[np.newaxis, :],
                                 tar_u[np.newaxis, :],
                                 tar_v[np.newaxis, :]), axis=0)
        tar_swh = swh[istep + hourModel, :]
        tar_mwp = mwp[istep + hourModel, :]
        tar_mwd = mwd[istep + hourModel, :]
        res_out = np.concatenate((tar_swh[np.newaxis, :],
                                 tar_mwp[np.newaxis, :],
                                 tar_mwd[np.newaxis, :]), axis=0)
        resAll_in.append(res_in)
        resAll_out.append(res_out)

    return np.asarray(resAll_in)[np.newaxis, :].transpose(1, 0, 3, 4, 2), \
           np.asarray(resAll_out)[np.newaxis, :].transpose(1, 0, 3, 4, 2)

class BasicDataset_ERA5YearlyScale(Dataset):
    def __init__(self, year, hourModel):

        # self.n_in = n_in
        # self.n_out = n_out
        self.resAll_in, self.resAll_out = pre_era5_data_npy_scale(year, hourModel)

    def __len__(self):
        return self.resAll_in.shape[0]

    def __getitem__(self, i):
        return torch.from_numpy(self.resAll_in[i, :]), \
               torch.from_numpy(self.resAll_out[i, :])


def get_parameter_names(model, forbidden_layer_types):
    r"""
    Returns the names of the model parameters that are not inside a forbidden layer.

    Borrowed from https://github.com/huggingface/transformers/blob/623b4f7c63f60cce917677ee704d6c93ee960b4b/src/transformers/trainer_pt_utils.py#L996
    """
    result = []
    for name, child in model.named_children():
        result += [
            f"{name}.{n}"
            for n in get_parameter_names(child, forbidden_layer_types)
            if not isinstance(child, tuple(forbidden_layer_types))
        ]
    # Add model specific parameters (defined with nn.Parameter) since they are not in any child.
    result += list(model._parameters.keys())
    return result

def warmup_lambda(warmup_steps, min_lr_ratio=0.1):
    def ret_lambda(epoch):
        if epoch <= warmup_steps:
            return min_lr_ratio + (1.0 - min_lr_ratio) * epoch / warmup_steps
        else:
            return 1.0
    return ret_lambda