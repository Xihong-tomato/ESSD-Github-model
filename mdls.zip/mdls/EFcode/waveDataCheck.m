close all;clear;clc
ncfile = 'c:\Users\liuy\Desktop\19790101Allwave.nc';
lonMesh = ncread(ncfile, 'longitude');
latMesh  = ncread(ncfile, 'latitude');
swh  = ncread(ncfile, 'mwp'); % Significant height of combined wind waves and swell
shww = ncread(ncfile, 'mpww'); % Significant height of wind waves
shts = ncread(ncfile, 'mpts'); %  Significant height of total swell
bb =sqrt( shww.^2 + shts.^2) ;
aa = swh - bb;
cc = squeeze(aa(:, :, 2));
load coast.mat
pcolor(lonMesh, latMesh, cc'); shading flat;colorbar
hold on
plot(long, lat, 'k-')
title('pcolor(cc)')
% p140121  = ncread(ncfile, 'p140121');
% p140124  = ncread(ncfile, 'p140124');
% p140127  = ncread(ncfile, 'p140127');
% dwww  = ncread(ncfile, 'dwww');
% dwps  = ncread(ncfile, 'dwps');
% wdw  = ncread(ncfile, 'wdw');
% aa = 4 .* sqrt(dwps) - shts;