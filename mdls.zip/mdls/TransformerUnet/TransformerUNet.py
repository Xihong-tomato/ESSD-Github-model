from typing import List, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F

from .utils import config
from .EncoderDecoder import ConvBlock, EncoderLayer, DecoderLayer

DEVICE = config.get_device()

class TransformerUNet(nn.Module):
    def __init__(self, channels: Tuple[int], out_channels=1, num_heads=2, is_residual: bool = False, bias=False) -> None:
        super(TransformerUNet, self).__init__()

        self.channels = channels
        self.pos_encoding = PositionalEncoding()
        self.encode = nn.ModuleList([EncoderLayer(channels[i], channels[i + 1], is_residual, bias) for i in range(len(channels) - 2)])
        self.bottle_neck = ConvBlock(channels[-2], channels[-1], is_residual, bias)
        self.mhsa = MultiHeadSelfAttention(channels[-1], num_heads, bias)
        self.mhca = nn.ModuleList([MultiHeadCrossAttention(channels[i], num_heads, channels[i], channels[i + 1], bias) for i in reversed(range(1, len(channels) - 1))])
        self.decode = nn.ModuleList([DecoderLayer(channels[i + 1], channels[i], is_residual, bias) for i in reversed(range(1, len(channels) - 1))])
        self.output = nn.Conv2d(channels[1], out_channels, 1)

        self.init_weights()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        skip_x_list: List[torch.Tensor] = []
        original_size = x.shape[-2:]  # 保存原始尺寸
        
        # 处理输入维度
        adjust_output_flag = False
        if x.ndim == 5:
            # 从BTXYC转换为BCHW
            # 首先压缩时间维度(T=1)，然后调整通道位置
            x = x.squeeze(1).permute(0, 3, 1, 2)
            adjust_output_flag = True
        
        # 计算需要填充的尺寸
        b, c, h, w = x.size()
        min_size = 2 ** (len(self.encode) + 1)  # 确保能整除的最小尺寸
        pad_h = (min_size - h % min_size) % min_size
        pad_w = (min_size - w % min_size) % min_size
        
        # 对称填充输入
        if pad_h > 0 or pad_w > 0:
            x = F.pad(x, (0, pad_w, 0, pad_h), mode='reflect')

        # 编码路径
        for i in range(len(self.channels) - 2):
            skip_x, x = self.encode[i](x)
            skip_x_list.append(skip_x)

        x = self.bottle_neck(x)
        x = self.pos_encoding(x)
        x = self.mhsa(x)

        # 解码路径
        for i, skip_x in enumerate(reversed(skip_x_list)):
            x = self.pos_encoding(x)
            skip_x = self.pos_encoding(skip_x)
            skip_x = self.mhca[i](skip_x, x)
            x = self.decode[i](skip_x, x)
        
        # 裁剪到原始尺寸
        if pad_h > 0 or pad_w > 0:
            x = x[:, :, :h, :w]
        
        # 处理输出维度
        if adjust_output_flag:
            out = self.output(x).unsqueeze(1).permute(0, 1, 3, 4, 2) #BTCHW -> BTHWC
        else:
            out = self.output(x)
        return out
    
    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_uniform_(m.weight.data)
                if m.bias is not None:
                    m.bias.data.fill_(0.1)

class MultiHeadSelfAttention(nn.Module):
    def __init__(self, embed_dim: int, num_heads: int, bias=False) -> None:
        super(MultiHeadSelfAttention, self).__init__()

        self.mha = nn.MultiheadAttention(embed_dim, num_heads, bias=bias, batch_first=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.size()
        x = x.permute(0, 2, 3, 1).view((b, h * w, c))
        x, _ = self.mha(x, x, x, need_weights=False)
        return x.view((b, h, w, c)).permute(0, 3, 1, 2)

class MultiHeadCrossAttention(nn.Module):
    def __init__(self, embed_dim: int, num_heads: int, channel_S: int, channel_Y: int, bias=False) -> None:
        super(MultiHeadCrossAttention, self).__init__()

        self.conv_S = nn.Sequential(
            nn.MaxPool2d(2),
            nn.Conv2d(channel_S, channel_S, 1, bias=bias),
            nn.BatchNorm2d(channel_S),
            nn.ReLU()
        )

        self.conv_Y = nn.Sequential(
            nn.Conv2d(channel_Y, channel_S, 1, bias=bias),
            nn.BatchNorm2d(channel_S),
            nn.ReLU()
        )

        self.mha = nn.MultiheadAttention(embed_dim, num_heads, bias=bias, batch_first=True)

        # 使用插值上采样而不是转置卷积，避免尺寸问题
        self.upsample = nn.Sequential(
            nn.Conv2d(channel_S, channel_S, 1, bias=bias),
            nn.BatchNorm2d(channel_S),
            nn.Sigmoid()
        )

    def forward(self, s: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        s_enc = s
        s = self.conv_S(s)
        y = self.conv_Y(y)

        b, c, h, w = s.size()
        s = s.permute(0, 2, 3, 1).view((b, h * w, c))

        b, c, h_y, w_y = y.size()
        y = y.permute(0, 2, 3, 1).view((b, h_y * w_y, c))

        y, _ = self.mha(y, y, s, need_weights=False)
        y = y.view((b, h_y, w_y, c)).permute(0, 3, 1, 2)
        
        y = self.upsample(y)
        
        # 使用双线性插值上采样到s_enc的尺寸
        y = F.interpolate(y, size=s_enc.shape[-2:], mode='bilinear', align_corners=False)

        return torch.mul(y, s_enc)

class PositionalEncoding(nn.Module):
    def __init__(self) -> None:
        super(PositionalEncoding, self).__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.size()
        pos_encoding = self.positional_encoding(h * w, c)
        pos_encoding = pos_encoding.permute(1, 0).unsqueeze(0).repeat(b, 1, 1)
        x = x.view((b, c, h * w)) + pos_encoding
        return x.view((b, c, h, w))

    def positional_encoding(self, length: int, depth: int) -> torch.Tensor:
        depth = depth / 2

        positions = torch.arange(length, dtype=config.DTYPE, device=DEVICE)
        depths = torch.arange(depth, dtype=config.DTYPE, device=DEVICE) / depth

        angle_rates = 1 / (10000**depths)
        angle_rads = torch.einsum('i,j->ij', positions, angle_rates)

        pos_encoding = torch.cat((torch.sin(angle_rads), torch.cos(angle_rads)), dim=-1)

        return pos_encoding