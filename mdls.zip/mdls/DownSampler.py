#import antialiased_cnns
import torch.nn as nn



class DownSampler(nn.Module):
    def __init__(self, params):
        super().__init__()
        # Written By Min  + params['output_dim']
        self.img_encode = nn.Sequential(
            nn.Conv2d(in_channels=params['input_dim'], kernel_size=1, stride=1, padding=0,
                      out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                  out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1)
        )
        # self.img_encodeBN = nn.Sequential(
        #     nn.Conv2d(in_channels=params['input_dim'] + params['output_dim'], kernel_size=1, stride=1, padding=0,
        #               out_channels=params['hidden_dim']),
        #     nn.BatchNorm2d(num_features=params['hidden_dim']),
        #     nn.LeakyReLU(0.1),
        #     nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
        #               out_channels=params['hidden_dim']),
        #     nn.BatchNorm2d(num_features=params['hidden_dim']),
        #     nn.LeakyReLU(0.1),
        #     nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
        #               out_channels=params['hidden_dim']),
        #     nn.BatchNorm2d(num_features=params['hidden_dim']),
        #     nn.LeakyReLU(0.1),
        #     nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
        #               out_channels=params['hidden_dim']),
        #     nn.BatchNorm2d(num_features=params['hidden_dim']),
        #     nn.LeakyReLU(0.1)
        # )

    def forward(self, x):
        out = self.img_encode.forward(x)
        return out

class DownSamplerBN(nn.Module):
    def __init__(self, params):
        super().__init__()

        self.img_encode = nn.Sequential(
            nn.Conv2d(in_channels=params['input_dim'] + params['output_dim'], kernel_size=1, stride=1, padding=0,
                      out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1)
        )

        self.img_encodeBN = nn.Sequential(
            nn.Conv2d(in_channels=params['input_dim'] + params['output_dim'], kernel_size=1, stride=1, padding=0,
                      out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1)
        )

    def forward(self, x):
        out = self.img_encodeBN.forward(x)
        return out

class DownSamplerBNSteps(nn.Module):
    def __init__(self, params):
        super().__init__()

        self.img_encodeBN = nn.Sequential(
            nn.Conv2d(in_channels=params['input_dim'] + params['output_window_size'], kernel_size=1, stride=1, padding=0,
                      out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1,
                      out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1)
        )

    def forward(self, x):
        out = self.img_encodeBN.forward(x)
        return out
