import torch.nn as nn
import torch
from axial_attention import AxialAttention, AxialPositionalEmbedding
import numpy as np
class CNN1_At(nn.Module):
    def __init__(self,in_channels, out_channels, H_in, W_in):
        super(CNN1_At, self).__init__()
        self.H = H_in
        self.W = W_in
        self.middleChannels = 32
        #self.mask = torch.from_numpy(np.tile(mask, (self.middleChannels, 1, 1)))
        num_att_layers = 2
        self.conv1 = nn.Sequential(
                nn.Conv2d(in_channels, 32, 3, padding=1),
                nn.BatchNorm2d(32),
                nn.Conv2d(32, self.middleChannels, 3, padding=1),
                nn.BatchNorm2d(self.middleChannels),
                nn.Conv2d(self.middleChannels, self.middleChannels, 3, padding=1),
                nn.BatchNorm2d(self.middleChannels),
                nn.Conv2d(self.middleChannels, self.middleChannels, 3, padding=1)
            )
        self.position_embedding = AxialPositionalEmbedding(
            dim=self.middleChannels, shape=(self.H, self.W)
        )
        self.head = nn.Conv2d(self.middleChannels, out_channels, kernel_size=(1, 1))
        self.temporal_agg = nn.Sequential(
            *[
                AxialAttention(dim=self.middleChannels, dim_index=1, heads=8, num_dimensions=2)
                for _ in range(num_att_layers)
            ]
        )
    def forward(self, x):
        x0 = self.conv1(x)
        x1 = self.position_embedding(x0)
        # B, T, _, _ = x1.shape
        # x2 = x1[torch.tile(self.mask, (B, T, 1, 1))].reshape(B, T, -1, 1)
        #x1 = x1.masked_fill(torch.logical_not(self.mask), -1E18)
        #dots = torch.softmax(dots, dim=-1) * self.mask
        x3 = self.temporal_agg(x1)
        # x1[torch.tile(self.mask, (B, T, 1, 1))] = x3
        x4 = self.head(x3)
        #output = self.fc(output)
        #print(output.shape)
        return x4   # return x for visualization
		
		
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.fc  = nn.Sequential(
            nn.Linear(2, 256),
            #nn.Dropout(0.5),
			nn.ReLU(),
			nn.Linear(256,256),
            nn.ReLU(),
			nn.Linear(256,256),
            nn.ReLU(),
			nn.Linear(256,256),
            #nn.Dropout(0.5),
			nn.ReLU(),
            nn.Linear(256, 1),
        )

    def forward(self, x):
        output = self.fc(x)
        #print(x.shape)
        return output   # return x for visualization


