import matplotlib.pyplot as plt
import numpy as np
#from utils0907 import BasicDataset_ERA5YearlyScale_LSTM
from torch.utils.data import DataLoader, random_split
import torch
import os
import random
import torch.nn as nn
from torch import optim
from tqdm import tqdm
#from utils0907 import adjust_learning_rate
import netCDF4 as nc
#import xarray as xr
from model.Encode2Decode import Encode2Decode_SAconvLSTM_MultiStep, Encode2Decode_convLSTM_MultiStep
from model.Encode2Decode import Encode2Decode_SATianchi_MultiStep
# from utils.earlystopping import EarlyStopping
import xlwings as xw
import xlsxwriter
import datetime
from torchsummary import summary

def write_xls_file(epoch, lossRes, outexcel):

    # Create xls file
    workbook = xlsxwriter.Workbook(outexcel)
    worksheet1 = workbook.add_worksheet(str(epoch))
    years = list(lossRes[epoch])
    for ii in range(len(years)):
        iyear = years[ii]
        worksheet1.write_row(ii, 0, [iyear])
        worksheet1.write_row(ii, 1, lossRes[epoch][iyear])
    # worksheet1.write_row(ii+1, 1, lossRes[epoch]['lossTotal']
    workbook.close()

def set_seed(seed = 324):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)


class Model():
    def __init__(self, params, loading_path=None, set_device=4):
        if params['model_cell'] == 'sa_convlstm':
            self.model = Encode2Decode_SAconvLSTM_MultiStep(params).to(params['device'])
        elif  params['model_cell'] == 'convlstm':
            self.model = Encode2Decode_convLSTM_MultiStep(params).to(params['device'])
        else:
            self.model = Encode2Decode_SATianchi_MultiStep(params).to(params['device'])
        self.loss = params['loss']
        if self.loss == 'SSIM':
            # self.criterion = SSIM().to(device)
            self.criterion = nn.MSELoss()
        elif self.loss == 'L2':
            self.criterion = nn.MSELoss()
        else:
            self.criterion = nn.L1Loss()
        self.output = params['output_dim']
        self.device = params['device']
        self.optim = optim.Adam(self.model.parameters(), lr=params['lr'])
        self.params = params

    def train(self, year0, year1, epochs, savePath):
        # early_stopping = EarlyStopping(patience=20, verbose=True)
        lrOut = self.params['lr']
        x_train = []
        avg_train_losses = []
        ssr_ratio = 1
        year2Pro = []
        [year2Pro.append(_) for _ in range(year0, year1 + 1)]

        lossRes = {}
        for epoch in range(epochs + 1):
            lossRes[epoch] = {}
            lossRes[epoch]['lossTotal'] = []

        for epoch in range(epochs + 1):
            random.shuffle(year2Pro)
            train_losses, val_losses = [], []
            self.model.train()
            epoch_loss = 0

            val_epoch_loss = 0.0
            ssr_ratio = ssr_ratio * (0.9 ** (epoch // 5))
            ssr_ratio = max( ssr_ratio, 0.1 )

            nowStr = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            outexcel = savePath + r"\convlstm128_7Years_" + nowStr + "_" + str(epoch) + r".xls"

            BATCH_SIZE = 5
            totalNum = np.ceil((year1 - year0 + 1) * 8741 / BATCH_SIZE)
            with tqdm(total=totalNum, desc=f'Epoch {epoch + 1}') as pbar:
                for iyear in range(year1 - year0 + 1):
                    lossRes[epoch][year2Pro[iyear]] = []
                    epoch_loss_year = 0
                    datasetTrain = BasicDataset_ERA5YearlyScale_LSTM(year2Pro[iyear], n_in, n_out)
                    train_loader = DataLoader(datasetTrain, batch_size=BATCH_SIZE, shuffle=True,
                                          num_workers=0, pin_memory=True)
                    for batch_in, batch_out in train_loader:
                        batch_in = batch_in.to(device=self.device, dtype=torch.float32)
                        batch_out = batch_out.to(device=self.device, dtype=torch.float32)
                        data_out = self.model(batch_in)
                        loss = self.criterion(data_out, target=batch_out)
                        self.optim.zero_grad()  # zero the gradient buffers
                        loss.backward()
                        self.optim.step()  # Does the update
                        train_losses.append(loss.item())
                        epoch_loss += loss.item()
                        epoch_loss_year += loss.item()
                        pbar.set_postfix(**{'loss(batch)': loss.item(), 'Loss(Total)': epoch_loss, 'lr': lrOut})
                        pbar.update()
                    lossRes[epoch][year2Pro[iyear]].append(epoch_loss_year)
            lossRes[epoch]['lossTotal'].append( epoch_loss )
            write_xls_file(epoch, lossRes, outexcel)
            avg_train_losses.append(np.average(train_losses))
            x_train.append(epoch)
            lrOut = adjust_learning_rate(self.params['lr'], self.optim, epoch, self.params['lrStep'])
            torch.save(self.model.state_dict(), os.path.join(savePath, r'convlstm_ERA5_7Years_layer1_in24_Out12_tanh128_3var_' + str(epoch) + '.h5'))


if __name__ == '__main__':
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    #set_seed()
    year0 = 2014
    year1 = 2020
    n_in = 24
    n_out = 12
    savePath = r'l:\00AI\dataTrain\multiStep\modelFinal'
    lrStep = 10
    lr = 5.e-4
    epochs = 50
    saveStep = 1
    loss = 'L2'
    # hid_dim_EnDecode = 64  # 16
    # hid_dimAttn = [64, 64, 64, hid_dim_EnDecode]
    # att_hid_dim = 32
    hid_dim_EnDecode = 128  # 16
    hid_dimAttn =[32] # 64, 64, hid_dim_EnDecode]
    att_hid_dim = 16
    n_layers = 1
    bias = True
    # 1) sa-convlstm
    # 2) convlstm (else for now)
    # model_name = 'sa_convlstm'
    model_name = 'convlstm'
    # model_name = 'sa_convlstm_tianchi'
    params = {'input_dim': 2, 'output_dim': 3,
              'padding': 1, 'lr': lr, 'device': device,
              'att_hidden_dim': att_hid_dim, 'kernel_size': 3, 'hidden_dim': hid_dim_EnDecode,
              'convlstm_hidden_dim': hid_dimAttn,
              'n_layers': n_layers, 'loss': loss,
              'input_window_size': n_in, 'output_window_size': n_out,
              'model_cell': model_name, 'bias': bias, 'saveStep': saveStep,
              'lrStep': lrStep, 'add_BN': True,
              'train': True}

    model = Model(params)
    summary(model.model, (24, 2, 64, 72))
    # model.train(year0, year1, epochs=epochs,
    #             savePath=savePath)





