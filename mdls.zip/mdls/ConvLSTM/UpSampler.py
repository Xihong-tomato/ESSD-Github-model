#import antialiased_cnns
import torch
import torch.nn as nn



class UpSampler(nn.Module):
    def __init__(self, params):
        super().__init__()
        self.BN = params['add_BN']  # 'add_BN': True
        self.layers = nn.ModuleDict()
        self.layers['in_0'] = nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim'])
        self.layers['activate'] = nn.LeakyReLU(0.1)
        self.layers['out_0'] = nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                      out_channels=1)
        self.layers['out_1'] = nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                                         out_channels=1)
        self.layers['out_2'] = nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                                         out_channels=1)

        self.img_decode = nn.Sequential(
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                      out_channels=params['output_dim'])
        )
        # self.img_decodeBN = nn.Sequential(
        #     nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
        #                        out_channels=params['hidden_dim']),
        #     nn.BatchNorm2d(num_features=params['hidden_dim']),
        #     nn.LeakyReLU(0.1),
        #     nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
        #                        out_channels=params['hidden_dim']),
        #     nn.BatchNorm2d(num_features=params['hidden_dim']),
        #     nn.LeakyReLU(0.1),
        #     nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
        #                        out_channels=params['hidden_dim']),
        #     nn.BatchNorm2d(num_features=params['hidden_dim']),
        #     nn.LeakyReLU(0.1),
        #     nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
        #               out_channels=params['output_dim'])
        # )

    def forward(self, x):
        # _x = self.layers['in_0'](x)
        # _x = self.layers['activate'](_x)
        # _x = self.layers['in_0'](_x)
        # _x = self.layers['activate'](_x)
        # _x = self.layers['in_0'](_x)
        # _x = self.layers['activate'](_x)
        # #
        # x0 = self.layers['out_0'](_x)
        # x1 = self.layers['out_1'](_x)
        # x2 = torch.tanh(self.layers['out_2'](_x))
        # out = torch.stack([x0, x1, x2], dim = 1)
        # return out[:, :, 0, :, :] #self.img_decode.forward(x)
        # if self.BN:
        #     out = self.img_decodeBN.forward(x)
        # else:
        out = self.img_decode.forward(x)
        return out[:]

class UpSamplerBN(nn.Module):
    def __init__(self, params):
        super().__init__()
        self.BN = params['add_BN']  # 'add_BN': True
        self.layers = nn.ModuleDict()
        self.layers['in_0'] = nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim'])
        self.layers['activate'] = nn.LeakyReLU(0.1)
        self.layers['out_0'] = nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                      out_channels=1)
        self.layers['out_1'] = nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                                         out_channels=1)
        self.layers['out_2'] = nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                                         out_channels=1)

        self.img_decode = nn.Sequential(
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                      out_channels=params['output_dim'])
        )
        self.img_decodeBN = nn.Sequential(
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.ConvTranspose2d(in_channels=params['hidden_dim'], kernel_size=3, stride=2, padding=1, output_padding=1,
                               out_channels=params['hidden_dim']),
            nn.BatchNorm2d(num_features=params['hidden_dim']),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=params['hidden_dim'], kernel_size=1, stride=1, padding=0,
                      out_channels=params['output_dim'])
        )

    def forward(self, x):
        # _x = self.layers['in_0'](x)
        # _x = self.layers['activate'](_x)
        # _x = self.layers['in_0'](_x)
        # _x = self.layers['activate'](_x)
        # _x = self.layers['in_0'](_x)
        # _x = self.layers['activate'](_x)
        # #
        # x0 = self.layers['out_0'](_x)
        # x1 = self.layers['out_1'](_x)
        # x2 = torch.tanh(self.layers['out_2'](_x))
        # out = torch.stack([x0, x1, x2], dim = 1)
        # return out[:, :, 0, :, :] #self.img_decode.forward(x)
        # if self.BN:
        out = self.img_decodeBN.forward(x)
        # else:
        #     out = self.img_decode.forward(x)
        return out[:]