from mdls.sa_convLSTM_cell import SA_Convlstm_cell
from mdls.convLSTM_cell import ConvLSTMCell
#from mdls.sa_convlstm import SAConvLSTM
import torch
import torch.nn as nn
from ConditionTime import ConditionTime
from TimeDistributed import TimeDistributed
from DownSampler import DownSampler
from UpSampler import UpSampler

class Encode2Decode_convLSTM_MultiStep(nn.Module):  # self-attention convlstm for spatiotemporal prediction model
    def __init__(self, params):
        super(Encode2Decode_convLSTM_MultiStep, self).__init__()
        # hyperparams
        self.cells, self.bns, self.decoderCells = [], [], []
        self.n_layers = params['n_layers']
        self.input_window_size = params['input_window_size']
        self.output_window_size = params['output_window_size']
        self.device = params['device']
        self.img_encode = DownSampler(params)
        self.img_decode = UpSampler(params)

        for i in range(params['n_layers']):
            params['input_dim'] == params['hidden_dim'] if i == 0 else params['hidden_dim']
            params['hidden_dim'] == params['hidden_dim']
            self.cells.append(ConvLSTMCell(params))
            self.bns.append(nn.LayerNorm((params['hidden_dim'], 16, 16)))  # Use layernorm

        self.cells = nn.ModuleList(self.cells)

        self.bns = nn.ModuleList(self.bns)
        self.decoderCells = nn.ModuleList(self.decoderCells)

        # Linear
        self.decode_conv = nn.Conv2d(in_channels=self.output_window_size,
                                     out_channels=self.output_window_size,
                                     kernel_size=(3, 3),
                                     padding=(1, 1))

        self.ct = ConditionTime(params['output_dim'])
        self.image_encoder = TimeDistributed(self.img_encode, low_mem=True)
        self.image_decoder = TimeDistributed(self.img_decode, low_mem=True) #
    def forward(self, x, hidden=None):

        # x = self.ct(x, fstep=0)
        x = self.image_encoder(x)
        if hidden == None:
            hidden = self.init_hidden(x)

        total_steps = self.input_window_size + self.output_window_size - 1

        for i, cell in enumerate(self.cells):
            out_layer = []
            hid = hidden[i]
            for t in range(total_steps):
                if t < self.input_window_size:
                    input_ = x[:, t]
                else:
                    input_ = out_layer[t - 1]
                out, hid = cell(input_, hid)
                out_layer.append(out)
            out_layer = torch.stack(out_layer, dim=1)  # output predictions
            x = out_layer

        res0 = out_layer[:, self.output_window_size * -1:]

        out = self.image_decoder(res0)

        # for multi var output
        # var0 = self.decode_conv(out[:, :, 0, :])
        # var1 = self.decode_conv(out[:, :, 1, :])
        # var2 = self.decode_conv(out[:, :, 2, :])
        #
        # out = torch.stack([var0, var1, var2], dim=2)

        return torch.tanh(out)

    def init_hidden(self, inputs):
        states = []
        batch_size, _, _, height, width = inputs.size()
        for i in range(self.n_layers):
            states.append(self.cells[i].init_hidden(batch_size, (height, width)))
        return states

class Encode2Decode_SATianchi_MultiStep(nn.Module):  # self-attention convlstm for spatiotemporal prediction model
    def __init__(self, params):
        super(Encode2Decode_SATianchi_MultiStep, self).__init__()
        # hyperparams
        self.cells, self.bns, self.decoderCells = [], [], []
        self.n_layers = params['n_layers']
        self.input_window_size = params['input_window_size']
        self.output_window_size = params['output_window_size']
        self.device = params['device']
        self.img_encode = DownSampler(params)
        self.img_decode = UpSampler(params)

        for i in range(params['n_layers']):
            params['input_dim'] == params['hidden_dim'] if i == 0 else params['hidden_dim']
            params['hidden_dim'] == params['hidden_dim']
            self.cells.append(SAConvLSTM(params))
            self.bns.append(nn.LayerNorm((params['hidden_dim'], 16, 16)))  # Use layernorm
        self.SAmodel = SAConvLSTM(params)
        self.cells = nn.ModuleList(self.cells)

        self.bns = nn.ModuleList(self.bns)
        self.decoderCells = nn.ModuleList(self.decoderCells)

        # Linear
        self.decode_conv = nn.Conv2d(in_channels=self.output_window_size,
                                     out_channels=self.output_window_size,
                                     kernel_size=(3, 3),
                                     padding=(1, 1))

        self.ct = ConditionTime(params['output_dim'])
        self.image_encoder = TimeDistributed(self.img_encode, low_mem=True)
        self.image_decoder = TimeDistributed(self.img_decode, low_mem=True) #

    def forward(self, x):

        # x = self.ct(x, fstep=0)
        x = self.image_encoder(x)
        res0 = self.SAmodel(x)
        out = self.image_decoder(res0)

        # for multi var output
        # var0 = self.decode_conv(out[:, :, 0, :])
        # var1 = self.decode_conv(out[:, :, 1, :])
        # var2 = self.decode_conv(out[:, :, 2, :])
        #
        # out = torch.stack([var0, var1, var2], dim=2)

        return torch.tanh(out)



class Encode2Decode_SAconvLSTM_MultiStep(nn.Module):  # self-attention convlstm for spatiotemporal prediction model
    def __init__(self, params):
        super(Encode2Decode_SAconvLSTM_MultiStep, self).__init__()
        # hyperparams
        self.cells, self.bns, self.decoderCells = [], [], []
        self.n_layers = params['n_layers']
        self.input_window_size = params['input_window_size']
        self.output_window_size = params['output_window_size']
        self.device = params['device']
        self.img_encode = DownSampler(params)
        self.img_decode = UpSampler(params)

        for i in range(params['n_layers']):
            params['input_dim'] == params['hidden_dim'] if i == 0 else params['hidden_dim']
            params['hidden_dim'] == params['hidden_dim']
            self.cells.append(SA_Convlstm_cell(params))
            self.bns.append(nn.LayerNorm((params['hidden_dim'], 16, 16)))  # Use layernorm

        self.cells = nn.ModuleList(self.cells)

        self.bns = nn.ModuleList(self.bns)
        self.decoderCells = nn.ModuleList(self.decoderCells)

        # Linear
        self.decode_conv = nn.Conv2d(in_channels=self.output_window_size,
                                     out_channels=self.output_window_size,
                                     kernel_size=(3, 3),
                                     padding=(1, 1))

        self.ct = ConditionTime(params['output_dim'])
        self.image_encoder = TimeDistributed(self.img_encode, low_mem=True)
        self.image_decoder = TimeDistributed(self.img_decode, low_mem=True) #

    def forward(self, x, hidden=None):

        # x = self.ct(x, fstep=0)
        x = self.image_encoder(x)
        if hidden == None:
            hidden = self.init_hidden(x)

        total_steps = self.input_window_size + self.output_window_size - 1

        for i, cell in enumerate(self.cells):
            out_layer = []
            hid = hidden[i]
            for t in range(total_steps):
                if t < self.input_window_size:
                    input_ = x[:, t]
                else:
                    input_ = out_layer[t - 1]
                out, hid = cell(input_, hid)
                out_layer.append(out)
            out_layer = torch.stack(out_layer, dim=1)  # output predictions
            x = out_layer

        res0 = out_layer[:, self.output_window_size * -1:]

        out = self.image_decoder(res0)

        # for multi var output
        # var0 = self.decode_conv(out[:, :, 0, :])
        # var1 = self.decode_conv(out[:, :, 1, :])
        # var2 = self.decode_conv(out[:, :, 2, :])
        #
        # out = torch.stack([var0, var1, var2], dim=2)

        return torch.tanh(out)

    def init_hidden(self, inputs):
        states = []
        batch_size, _, _, height, width = inputs.size()
        for i in range(self.n_layers):
            states.append(self.cells[i].init_hidden(batch_size, (height, width)))
        return states

