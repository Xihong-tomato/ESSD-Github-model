import pandas as pd
import netCDF4 as nc
import os
import numpy as np
import random
import torch
from torch.utils.data import Dataset
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import xarray as xr

def adjust_learning_rate(lr, optimizer, epoch, lr_changestep):
    """Sets the learning rate to the initial LR decayed by 10 every args.step epochs"""
    if epoch > 1:
        lr = lr * (0.9 ** (epoch // lr_changestep))
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
    return lr

def rmse(preds, y):
    return np.sqrt(sum((preds - y) ** 2) / preds.shape[0])


def series_to_superised_out_2d(var2superised, n_in, n_out):
    nsteps = var2superised.shape[0]
    nlat = var2superised.shape[1]
    nlon = var2superised.shape[2]
    ncols = int(nsteps - n_out - n_in)  # lower bound are 0 .
    train_cols = []  # np.zeros((ncols, 12), dtype = int)
    for ii in range(ncols):
        if ii == 0:
            colTemp = np.linspace(n_in, n_in + n_out - 1, n_out)
            train_cols.append([int(_) for _ in colTemp])
        else:
            colTemp = colTemp + 1
            train_cols.append([int(_) for _ in colTemp])
    resAll_out = np.zeros((ncols, n_out, nlat, nlon), dtype=float)
    for ii in range(ncols):
        resAll_out[ii, :, :, :] = var2superised[np.asarray(train_cols[ii]), :, :]
    return resAll_out

def series_to_superised_inOut_2d(var2superised, n_in, n_out):
    nsteps = var2superised.shape[0]
    nlat = var2superised.shape[1]
    nlon = var2superised.shape[2]
    nt = n_in
    ncols = int(nsteps - n_out - n_in )  # lower bound are 0 .
    train_cols = []  # np.zeros((ncols, 12), dtype = int)
    for ii in range(ncols):
        if ii == 0:
            #colTemp = np.linspace(0, n_in - 1, n_in)
            colTemp = np.linspace(0, nt - 1, nt)
            train_cols.append([int(_) for _ in colTemp])
        else:
            colTemp = colTemp + 1
            train_cols.append([int(_) for _ in colTemp])
    resAll_in = np.zeros((ncols, nt, nlat, nlon), dtype=float)
    for ii in range(ncols):
        resAll_in[ii, :, :, :] = var2superised[np.asarray(train_cols[ii]), :, :]
    return resAll_in


def pre_era5_data_npy_scale(year, n_in, n_out):

    # ds = xr.open_dataset(era5file)
    u10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\u10Land0_%04d.npy"%(year, year), allow_pickle=True)
    v10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\v10Land0_%04d.npy" % (year, year), allow_pickle=True)
    mwd = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\mwd%04d.npy" % (year, year), allow_pickle=True)
    mwp = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\mwp%04d.npy" % (year, year), allow_pickle=True)
    swh = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\swh%04d.npy" % (year, year), allow_pickle=True)

    # nx1d = u10.shape[-1]
    # ny1d = u10.shape[-2]
    resAll_out = []
    resAll_out.append(series_to_superised_out_2d(swh, n_in, n_out))
    resAll_out.append(series_to_superised_out_2d(mwp, n_in, n_out))
    resAll_out.append(series_to_superised_out_2d(mwd, n_in, n_out))

    # ncols = _hs_out.shape[0]
    # resAll_out = np.zeros((ncols, n_out, 3, ny1d, nx1d), dtype=float)
    # resAll_out[:, :, 0, :, :] = _hs_out
    # resAll_out[:, :, 1, :, :] = _mwp_out
    # resAll_out[:, :, 2, :, :] = _mwd_out

    # resAll_in = np.zeros((ncols, n_in, 2, ny1d, nx1d), dtype=float)
    # resAll_in[:, :, 0, :, :] = series_to_superised_inOut_2d(u10, n_in, n_out)
    # resAll_in[:, :, 1, :, :] = series_to_superised_inOut_2d(v10, n_in, n_out)
    resAll_in = []
    resAll_in.append(series_to_superised_inOut_2d(u10, n_in, n_out))
    resAll_in.append(series_to_superised_inOut_2d(v10, n_in, n_out))

    return np.asarray(resAll_in).transpose(1, 2, 3, 4, 0), \
           np.asarray(resAll_out).transpose(1, 2, 3, 4, 0)
    # return resAll_in, resAll_out


class BasicDataset_ERA5YearlyScale(Dataset):
    def __init__(self, year, n_in, n_out):

        self.n_in = n_in
        self.n_out = n_out
        self.resAll_in, self.resAll_out = pre_era5_data_npy_scale(year, n_in, n_out)

    def __len__(self):
        return self.resAll_in.shape[0]

    def __getitem__(self, i):
        return torch.from_numpy(self.resAll_in[i, :]), \
               torch.from_numpy(self.resAll_out[i, :])
