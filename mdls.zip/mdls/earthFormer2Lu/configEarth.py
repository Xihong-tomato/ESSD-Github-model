import torch


class Configs:
    def __init__(self):
        pass


configs = Configs()

# trainer related
configs.input_shape = [24, 64, 72, 2]
configs.target_shape = [12, 64, 72, 3]
configs.device = torch.device('cuda:0')

configs.batch_size_test = 100
configs.batch_size = 8
#configs.lr = 0.001
configs.weight_decay = 0
configs.display_interval = 120
configs.num_epochs = 100
configs.early_stopping = True
configs.patience = 3
configs.gradient_clipping = False
configs.clipping_threshold = 1.

# lr warmup
configs.warmup = 3000
configs.lrStep = 10
configs.lr = 5.e-4
# data related
configs.input_dim = 2 # 4
configs.output_dim = 3

configs.input_length = 24
configs.output_length = 12

configs.input_gap = 1
configs.pred_shift = 24

# model
configs.d_model = 128
configs.patch_size = (4, 4)
configs.emb_spatial_size = 16 * 18
configs.nheads = 4
configs.dim_feedforward = 128
configs.dropout = 0.2
configs.num_encoder_layers = 3
configs.num_decoder_layers = 3

configs.ssr_decay_rate = 3.e-4
