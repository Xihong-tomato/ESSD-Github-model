import matplotlib.pyplot as plt
import numpy as np
from utils0907 import BasicDataset_ERA5YearlyScale
from torch.utils.data import DataLoader, random_split
import torch
import os
import random
import torch.nn as nn
from torch import optim
from tqdm import tqdm
from utils import adjust_learning_rate
import netCDF4 as nc
import xarray as xr
from earthFormerLight import TransformerModel
from model.Encode2Decode import Encode2Decode_SAconvLSTM_MultiStep, Encode2Decode_convLSTM_MultiStep
# from utils.earlystopping import EarlyStopping
from configEarth import configs

from datetime import datetime, timedelta
def ncgenForHour(ncfile2write, nx1d, ny1d):
    if os.path.exists(ncfile2write):
        os.remove(ncfile2write)
    if not os.path.exists(ncfile2write):
        ncfile = nc.Dataset(ncfile2write,
                            mode='w', format='NETCDF3_64BIT_OFFSET') #NETCDF4_CLASSIC
        print('     +> Create ncfile\n')
        ncfile.createDimension('time', None)
        ncfile.createDimension('X', size=nx1d)
        ncfile.createDimension('Y', size=ny1d)
        setattr(ncfile, 'title', "Convlstm wave res")
        now = datetime.now().strftime("%Y%m%d%H%M%S")
        setattr(ncfile, 'created', now)
        ncfile.createVariable('hs_SWAN', 'd', dimensions=('time', 'Y', 'X'))
        setattr(ncfile.variables['hs_SWAN'], 'long_name', 'hs from SWAN')
        ncfile.createVariable('hs_torch', 'd', dimensions=('time', 'Y', 'X'))
        setattr(ncfile.variables['hs_torch'], 'long_name', 'hs from convlstm')

        ncfile.createVariable('mwp_SWAN', 'd', dimensions=('time', 'Y', 'X'))
        setattr(ncfile.variables['mwp_SWAN'], 'long_name', 'mwp from SWAN')

        ncfile.createVariable('mwp_torch', 'd', dimensions=('time', 'Y', 'X'))
        setattr(ncfile.variables['mwp_torch'], 'long_name', 'mwp from convlstm')

        ncfile.createVariable('mwd_SWAN', 'd', dimensions=('time', 'Y', 'X'))
        setattr(ncfile.variables['mwd_SWAN'], 'long_name', 'mwd from SWAN')

        ncfile.createVariable('mwd_torch', 'd', dimensions=('time', 'Y', 'X'))
        setattr(ncfile.variables['mwd_torch'], 'long_name', 'mwd from convlstm')


        ncfile.createVariable('hs_rmse', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['hs_rmse'], 'long_name', 'RMSE of hs')
        ncfile.createVariable('hs_mape', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['hs_mape'], 'long_name', 'MAPE of hs')

        ncfile.createVariable('mwp_rmse', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['mwp_rmse'], 'long_name', 'RMSE of mwp')
        ncfile.createVariable('mwp_mape', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['mwp_mape'], 'long_name', 'MAPE of mwp')

        ncfile.createVariable('mwd_rmse', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['mwd_rmse'], 'long_name', 'RMSE of mwd')
        ncfile.createVariable('mwd_mape', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['mwd_mape'], 'long_name', 'MAPE of mwd')

        ncfile.createVariable('maskr', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['maskr'], 'long_name', 'Mask of land sea')
        ncfile.createVariable('lon', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['lon'], 'long_name', 'Longitude')
        #ncfile.variables['lon'][:] = self.x.reshape(-1, 1)
        ncfile.createVariable('lat', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['lat'], 'long_name', 'Latitude')
        #ncfile.variables['lat'][:] = self.y.reshape(-1, 1)
        ncfile.createVariable('time', 'd', dimensions=('time'))
        setattr(ncfile.variables['time'], 'long_name', 'time')
        setattr(ncfile.variables['time'], 'units', 'hours since 2000-01-01 00:00:00')
        ncfile.close()

def ncgen(ncfile2write, nx1d, ny1d, n_out):
    if os.path.exists(ncfile2write):
        os.remove(ncfile2write)
    if not os.path.exists(ncfile2write):
        ncfile = nc.Dataset(ncfile2write,
                            mode='w', format='NETCDF3_64BIT_OFFSET')
        print('     +> Create ncfile\n')
        ncfile.createDimension('time', size=0)
        ncfile.createDimension('n_out', size=n_out)
        ncfile.createDimension('X', size=nx1d)
        ncfile.createDimension('Y', size=ny1d)
        setattr(ncfile, 'title', "Convlstm wave res")
        now = datetime.now().strftime("%Y%m%d%H%M%S")
        setattr(ncfile, 'created', now)
        ncfile.createVariable('hs_SWAN', 'd', dimensions=('time', 'n_out', 'Y', 'X'))
        setattr(ncfile.variables['hs_SWAN'], 'long_name', 'hs from SWAN')
        ncfile.createVariable('hs_torch', 'd', dimensions=('time', 'n_out', 'Y', 'X'))
        setattr(ncfile.variables['hs_torch'], 'long_name', 'hs from convlstm')

        ncfile.createVariable('mwp_SWAN', 'd', dimensions=('time', 'n_out', 'Y', 'X'))
        setattr(ncfile.variables['mwp_SWAN'], 'long_name', 'mwp from SWAN')

        ncfile.createVariable('mwp_torch', 'd', dimensions=('time', 'n_out', 'Y', 'X'))
        setattr(ncfile.variables['mwp_torch'], 'long_name', 'mwp from convlstm')

        ncfile.createVariable('mwd_SWAN', 'd', dimensions=('time', 'n_out', 'Y', 'X'))
        setattr(ncfile.variables['mwd_SWAN'], 'long_name', 'mwd from SWAN')

        ncfile.createVariable('mwd_torch', 'd', dimensions=('time', 'n_out', 'Y', 'X'))
        setattr(ncfile.variables['mwd_torch'], 'long_name', 'mwd from convlstm')


        ncfile.createVariable('hs_rmse', 'd', dimensions=('n_out', 'Y', 'X'))
        setattr(ncfile.variables['hs_rmse'], 'long_name', 'RMSE of hs')
        ncfile.createVariable('hs_mape', 'd', dimensions=('n_out', 'Y', 'X'))
        setattr(ncfile.variables['hs_mape'], 'long_name', 'MAPE of hs')

        ncfile.createVariable('mwp_rmse', 'd', dimensions=('n_out', 'Y', 'X'))
        setattr(ncfile.variables['mwp_rmse'], 'long_name', 'RMSE of mwp')
        ncfile.createVariable('mwp_mape', 'd', dimensions=('n_out', 'Y', 'X'))
        setattr(ncfile.variables['mwp_mape'], 'long_name', 'MAPE of mwp')

        ncfile.createVariable('mwd_rmse', 'd', dimensions=('n_out', 'Y', 'X'))
        setattr(ncfile.variables['mwd_rmse'], 'long_name', 'RMSE of mwd')
        ncfile.createVariable('mwd_mape', 'd', dimensions=('n_out', 'Y', 'X'))
        setattr(ncfile.variables['mwd_mape'], 'long_name', 'MAPE of mwd')

        ncfile.createVariable('maskr', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['maskr'], 'long_name', 'Mask of land sea')
        ncfile.createVariable('lon', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['lon'], 'long_name', 'Longitude')
        #ncfile.variables['lon'][:] = self.x.reshape(-1, 1)
        ncfile.createVariable('lat', 'd', dimensions=('Y', 'X'))
        setattr(ncfile.variables['lat'], 'long_name', 'Latitude')
        #ncfile.variables['lat'][:] = self.y.reshape(-1, 1)
        ncfile.createVariable('time', 'd', dimensions=('time'))
        setattr(ncfile.variables['time'], 'long_name', 'time')
        setattr(ncfile.variables['time'], 'units', 'hours since 2000-01-01 00:00:00')
        ncfile.close()

def set_seed(seed = 324):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)


class Model():
    def __init__(self, params, loading_path=None, set_device=4):
        self.model = TransformerModel(configs.input_shape, configs.target_shape).to(device)
        self.device = device
        self.criterion = nn.MSELoss()
        self.optim = optim.Adam(self.model.parameters(), lr=configs.lr)
        self.configs = configs


    def evaluate_test(self, year0, year1, path, ncfile2write):
        self.model.to(self.device)
        self.model.load_state_dict(torch.load(path))

        # ncgen(ncfile2write, 56, 64, n_out)
        ncfileForMask = r"e:\wave_era5\WindWaveYearly\ERA5WindWave2021.nc"
        ds = xr.open_dataset(ncfileForMask)
        lon = ds.longitude[:].data
        lat = ds.latitude[:].data
        [xx, yy] = np.meshgrid(lon, lat)
        maskr0 = 1 - ds.maskr[:].data
        ds.close()

        swhMin = 0
        swhMax = 18.37
        mwpMin = 1.5
        mwpMax = 16.7
        mwdMin = -1
        mwdMax = 1
        self.model.eval()

        ssr_ratio = 1
        BATCH_SIZE = 1
        totalNum = np.ceil((year1 - year0 + 1) * 8740 / BATCH_SIZE)
        nt = 0
        with tqdm(total=totalNum) as pbar:
            for iyear in range(year0, year1 + 1):
                # datasetTrain = BasicDataset_ERA5YearlyScale(iyear, n_in, n_out)
                # train_loader = DataLoader(datasetTrain, batch_size=BATCH_SIZE, shuffle=False,
                #                           num_workers=0, pin_memory=True)
                u10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\u10Land0_%04d.npy" % (iyear, iyear),
                              allow_pickle=True)
                v10 = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\v10Land0_%04d.npy" % (iyear, iyear),
                              allow_pickle=True)
                mwd = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\mwd%04d.npy" % (iyear, iyear),
                              allow_pickle=True)
                mwp = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\mwp%04d.npy" % (iyear, iyear),
                              allow_pickle=True)
                swh = np.load(r"l:\00AI\dataTrain\multiStep\era5FileYearly_npy\%04d\swh%04d.npy" % (iyear, iyear),
                              allow_pickle=True)
                nsteps = u10.shape[0]
                nlat = u10.shape[1]
                nlon = u10.shape[2]
                ncols = int(nsteps - n_out - n_in)  # lower bound are 0 .
                tt = []
                t0 = datetime(iyear, 1, 1)
                [tt.append(t0 + timedelta(hours=1) * (_ + n_in)) for _ in range(nsteps)]
                train_colsOut = []  # np.zeros((ncols, 12), dtype = int)
                train_colsIn = []  # np.zeros((ncols, 12), dtype = int)
                for ii in range(ncols):
                    if ii == 0:
                        colTemp_out = np.linspace(n_in, n_in + n_out - 1, n_out)
                        train_colsOut.append([int(_) for _ in colTemp_out])

                        colTemp_in = np.linspace(0, n_in - 1, n_in)
                        train_colsIn.append([int(_) for _ in colTemp_in])
                    else:
                        colTemp_out = colTemp_out + 1
                        train_colsOut.append([int(_) for _ in colTemp_out])

                        colTemp_in = colTemp_in + 1
                        train_colsIn.append([int(_) for _ in colTemp_in])
                resAll_out = np.zeros((n_out, nlat, nlon, 3), dtype=float)
                resAll_in = np.zeros((n_in, nlat, nlon, 2), dtype=float)

                for ii in range(ncols):

                    resAll_in [:, :, :, 0] = u10[np.asarray(train_colsIn[ii]), :, :]
                    resAll_in [:, :, :, 1] = v10[np.asarray(train_colsIn[ii]), :, :]

                    resAll_out[:, :, :, 0] = swh[np.asarray(train_colsOut[ii]), :, :]
                    resAll_out[:, :, :, 1] = mwp[np.asarray(train_colsOut[ii]), :, :]
                    resAll_out[:, :, :, 2] = mwd[np.asarray(train_colsOut[ii]), :, :]

                    batch_in = torch.from_numpy(resAll_in[np.newaxis, :])
                    batch_out = torch.from_numpy(resAll_out[np.newaxis, :])
                #for batch_in, batch_out in train_loader:
                    batch_in = batch_in.to(device=self.device, dtype=torch.float32)
                    batch_out = batch_out.to(device=self.device, dtype=torch.float32)
                    data_out = self.model(batch_in)
                    outSWAN = torch.squeeze(batch_out[:]).cpu().detach().numpy()  #
                    outConvlstm = torch.squeeze(data_out[:]).cpu().detach().numpy()
                    # swh = np.log(swh) / np.log(20.0)
                    # mwp = 0.2 * (mwp - 6.7) / 1.65
                    # mwd = np.cos(mwd * np.pi / 180.0)
                    hsSWAN = np.exp(outSWAN[:, :, :, 0] * np.log(20.0))
                    hsConvlstm = np.exp(outConvlstm[:, :, :, 0] * np.log(20.0))
                    mwpSWAN = outSWAN[:, :, :, 1] * 5 * 1.65 + 6.7
                    mwpConvlstm = outConvlstm[:, :, :, 1] * 5 * 1.65 + 6.7
                    mwdSWAN = np.arccos( outSWAN[:, :, :, 2] )
                    mwdConvlstm = np.arccos( outConvlstm[:, :, :, 2] )
                    # hsSWAN = outSWAN[:] * (swhMax - swhMin) + swhMin
                    # hsConvlstm = outConvlstm[:] * (swhMax - swhMin) + swhMin
                    # hsSWAN = np.exp( outSWAN[:] * np.log(20) )
                    # hsConvlstm = np.exp( outConvlstm[:] * np.log(20) )
                    # mwp = 0.2 * (mwp - 6.7) / 1.65
                    # mwp = (mwp - 1.5) / (16.7 - 1.5)
                    # hsSWAN = np.arccos(outSWAN[:])  # * 5.0 * 1.65 + 6.7
                    # hsConvlstm = np.arccos(outConvlstm[:]) #outConvlstm[:] * 5.0 * 1.65 + 6.7
                    for ihour in range(n_out):
                        ncfile2write = os.path.join(ncfilePath,
                                                r"earth_in24_Out_12_layer1_tanh_3Var_PredHour%02d.nc" % (
                                                ihour))
                        if not os.path.exists(ncfile2write):
                            ncgenForHour(ncfile2write, 72, 64)
                            ncfile = nc.Dataset(ncfile2write, mode='r+')
                            ncfile.variables['lon'][:] = xx
                            ncfile.variables['lat'][:] = yy
                            ncfile.variables['maskr'][:] = maskr0
                            ncfile.close()
                        ncfile = nc.Dataset(ncfile2write, mode='r+')
                        ncfile.variables['time'][nt] = nt
                        ncfile.variables['hs_SWAN'][nt, :, :] = hsSWAN[ihour, :]
                        ncfile.variables['hs_torch'][nt, :, :] = hsConvlstm[ihour, :]
                        ncfile.variables['mwp_SWAN'][nt, :, :] = mwpSWAN[ihour, :]
                        ncfile.variables['mwp_torch'][nt, :, :] = mwpConvlstm[ihour, :]
                        ncfile.variables['mwd_SWAN'][nt, :, :] = mwdSWAN[ihour, :]
                        ncfile.variables['mwd_torch'][nt, :, :] = mwdConvlstm[ihour, :]
                        ncfile.close()
                    nt = nt + 1
                    pbar.update()
        # get rmse
        # ncfile = nc.Dataset(ncfile2write, mode='r+')
        # hsSWAN = np.asarray(ncfile.variables['hs_SWAN'])[:]
        # hsConv = np.asarray(ncfile.variables['hs_torch'])[:]
        #
        # hsRMSE = np.sqrt(np.sum((hsConv - hsSWAN) ** 2, 0) / hsConv.shape[0])
        # hsMAPE = np.mean(np.abs((hsSWAN - hsConv) / hsSWAN), 0)
        #
        # ncfile.variables['hs_rmse'][:, :] = hsRMSE
        # ncfile.variables['hs_mape'][:, :] = hsMAPE
        #
        # mwpSWAN = np.asarray(ncfile.variables['mwp_SWAN'])[:]
        # mwpConv = np.asarray(ncfile.variables['mwp_torch'])[:]
        #
        # mwpRMSE = np.sqrt(np.sum((mwpConv - mwpSWAN) ** 2, 0) / mwpConv.shape[0])
        # mwpMAPE = np.mean(np.abs((mwpSWAN - mwpConv) / mwpSWAN), 0)
        #
        # ncfile.variables['mwp_rmse'][:, :] = mwpRMSE
        # ncfile.variables['mwp_mape'][:, :] = mwpMAPE
        #
        # mwdSWAN = np.asarray(ncfile.variables['mwd_SWAN'])[:]
        # mwdConv = np.asarray(ncfile.variables['mwd_torch'])[:]
        #
        # mwdRMSE = np.sqrt(np.sum((mwdConv - mwdSWAN) ** 2, 0) / mwdConv.shape[0])
        # mwdMAPE = np.mean(np.abs((mwdSWAN - mwdConv) / mwdSWAN), 0)
        #
        # ncfile.variables['mwd_rmse'][:, :] = mwdRMSE
        # ncfile.variables['mwd_mape'][:, :] = mwdMAPE
        #
        # ncfile.close()


if __name__ == '__main__':
    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
    set_seed()

    year0 = 2017
    year1 = 2017
    n_in = 24
    n_out = 12

    lrStep = 5
    lr = 1.e-3
    epochs = 100
    saveStep = 5
    loss = 'L2'
    hid_dim = 128  # 16
    att_hid_dim = 64
    n_layers = 1
    bias = True
    # 1) sa-convlstm
    # 2) convlstm (else for now)
    # model_name = 'sa_convlstm'
    model_name = 'convlstm'
    model = Model(configs)

    modelFile = r'l:\00AI\dataTrain\multiStep\modelFinal\Transformer_ERA5_3Years_layer1_in24_Out12_tanh_3var_13.h5'
    # model.train(train_loader, val_loader, epochs=epochs,
    #             savePath=savePath)
    ncfilePath = r'l:\00AI\dataTrain\multiStep\modelFinal\res'

    model.evaluate_test(year0, year1, modelFile, ncfilePath)





