import matplotlib.pyplot as plt
import numpy as np
from utils0907 import BasicDataset_ERA5YearlyScale
from torch.utils.data import DataLoader, random_split
import torch
import os
import random
import torch.nn as nn
from torch import optim
from tqdm import tqdm
from utils0907 import adjust_learning_rate
import netCDF4 as nc
import xarray as xr
from earthFormerLight import TransformerModel
from configEarth import configs
# from utils.earlystopping import EarlyStopping
import xlwings as xw
import xlsxwriter
import datetime

def write_xls_file(epoch, lossRes, outexcel):

    # Create xls file
    workbook = xlsxwriter.Workbook(outexcel)
    worksheet1 = workbook.add_worksheet(str(epoch))
    years = list(lossRes[epoch])
    for ii in range(len(years)):
        iyear = years[ii]
        worksheet1.write_row(ii, 0, [iyear])
        worksheet1.write_row(ii, 1, lossRes[epoch][iyear])
    # worksheet1.write_row(ii+1, 1, lossRes[epoch]['lossTotal']
    workbook.close()

def set_seed(seed = 324):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)


class Model():
    def __init__(self, configs, loading_path=None, set_device=4):

        self.model = TransformerModel(configs.input_shape, configs.target_shape).to(configs.device)
        self.device = configs.device
        self.criterion = nn.MSELoss()
        self.optim = optim.Adam(self.model.parameters(), lr=configs.lr)
        self.configs = configs
    def train(self, year0, year1, epochs, savePath):
        # early_stopping = EarlyStopping(patience=20, verbose=True)
        lrOut = self.configs.lr
        x_train = []
        avg_train_losses = []
        ssr_ratio = 1
        year2Pro = []
        [year2Pro.append(_) for _ in range(year0, year1 + 1)]

        lossRes = {}
        for epoch in range(epochs + 1):
            lossRes[epoch] = {}
            lossRes[epoch]['lossTotal'] = []

        for epoch in range(epochs + 1):
            random.shuffle(year2Pro)
            train_losses, val_losses = [], []
            self.model.train()
            epoch_loss = 0

            ssr_ratio = ssr_ratio * (0.9 ** (epoch // 5))
            ssr_ratio = max( ssr_ratio, 0.1 )

            nowStr = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            outexcel = savePath + r"\transformer_3Years_" + nowStr + "_" + str(epoch) + r".xls"

            BATCH_SIZE = 5 #20
            totalNum = np.ceil((year1 - year0 + 1) * 8741 / BATCH_SIZE)*2
            with tqdm(total=totalNum, desc=f'Epoch {epoch + 1}') as pbar:
                for iyear in range(year1 - year0 + 1):
                    lossRes[epoch][year2Pro[iyear]] = []
                    epoch_loss_year = 0
                    datasetTrain = BasicDataset_ERA5YearlyScale(year2Pro[iyear], n_in, n_out)
                    for irepeat in range(2):
                        train_loader = DataLoader(datasetTrain, batch_size=BATCH_SIZE, shuffle=True,
                                                  num_workers=0, pin_memory=True)
                        for batch_in, batch_out in train_loader:
                            batch_in = batch_in.to(device=self.device, dtype=torch.float32)
                            batch_out = batch_out.to(device=self.device, dtype=torch.float32)
                            data_out = self.model(batch_in)
                            loss = self.criterion(data_out, target=batch_out)
                            self.optim.zero_grad()  # zero the gradient buffers
                            loss.backward()
                            self.optim.step()  # Does the update
                            train_losses.append(loss.item())
                            epoch_loss += loss.item()
                            epoch_loss_year += loss.item()
                            pbar.set_postfix(**{'loss(batch)': loss.item(), 'Loss(Total)': epoch_loss, 'lr': lrOut})
                            pbar.update()
                    lossRes[epoch][year2Pro[iyear]].append(epoch_loss_year)
            lossRes[epoch]['lossTotal'].append( epoch_loss )
            write_xls_file(epoch, lossRes, outexcel)
            avg_train_losses.append(np.average(train_losses))
            x_train.append(epoch)
            lrOut = adjust_learning_rate(self.configs.lr, self.optim, epoch, self.configs.lrStep)
            torch.save(self.model.state_dict(), os.path.join(savePath, r'Transformer_ERA5_3Years_layer1_in24_Out12_tanh_3var_' + str(epoch) + '.h5'))


if __name__ == '__main__':
    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
    set_seed()
    year0 = 2014
    year1 = 2016
    n_in = 24
    n_out = 12
    savePath = r'l:\00AI\dataTrain\multiStep\modelFinal'

    epochs = 100
    saveStep = 1
    loss = 'L2'

    # 1) sa-convlstm
    # 2) convlstm (else for now)
    # model_name = 'sa_convlstm'
    # model_name = 'convlstm'
    # model_name = 'sa_convlstm_tianchi'
    model_name = 'ST'

    model = Model(configs)
    modelFile = r'l:\00AI\dataTrain\multiStep\modelFinal\Transformer_ERA5_3Years_layer1_in24_Out12_tanh_3var_14.h5'
    model.model.load_state_dict(torch.load(modelFile))
    model.train(year0, year1, epochs=epochs,
                savePath=savePath)





