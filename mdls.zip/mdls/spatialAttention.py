import torch
import torch.nn as nn
import math
import torch.nn.functional as F

def attn(query, key, value):
    """
    Apply attention over the spatial dimension (S)
    Args:
        query, key, value: (N, C, S)
    Returns:
        output of the same size
    """
    scores = query.transpose(1, 2) @ key / math.sqrt(query.size(1))  # (N, S, S)
    attn = F.softmax(scores, dim=-1)
    output = attn @ value.transpose(1, 2)
    return output.transpose(1, 2)  # (N, C, S)

class SAAttnMem(nn.Module):
    def __init__(self, input_dim, d_model):
        """
        The self-attention memory module 
        """
        super().__init__()
        self.d_model = d_model
        self.input_dim = input_dim
        self.conv_h = nn.Conv2d(input_dim, d_model*3, kernel_size=1)

    def forward(self, h):
        hq, hk, hv = torch.split(self.conv_h(h), self.d_model, dim=1)
        N, C, H, W = hq.size()
        Zh = attn(hq.view(N, C, -1), hk.view(N, C, -1), hv.view(N, C, -1))  # (N, S, C)
        
        return Zh.view(N,C,H,W)