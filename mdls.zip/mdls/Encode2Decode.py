from mdls.sa_convLSTM_cell import *
from mdls.spatialAttention import SAAttnMem
from mdls.convLSTM_cell import ConvLSTMCell
import torch
import torch.nn as nn
#from ConditionTime import ConditionTime
#from TimeDistributed import TimeDistributed
from mdls.DownSampler import DownSampler
from mdls.UpSampler import UpSampler


class Encode2Decode_SpatialAttention(nn.Module):
    def __init__(self, params):
        super(Encode2Decode_SpatialAttention, self).__init__()
        self.device = params['device']
        self.conv1 = nn.Sequential(         # input shape (34, 64, 64)
            nn.Conv2d(params['input_dim'],32,1,1,0),  # output shape (64, 28, 28)
            nn.BatchNorm2d(32),
            #nn.Dropout(0.5),
            nn.ReLU(inplace=True),                      # activation
            #nn.MaxPool2d(1),    # 理论上没效果
            nn.Conv2d(32,64,1,1,0),
            #nn.Dropout(0.5),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            #nn.MaxPool2d(1),    # output shape (64, Y/4, X/4)
            nn.Conv2d(64,64,1,1,0),
            #nn.Dropout(0.5),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            #nn.MaxPool2d(1),    # output shape
            nn.Conv2d(64,64,1,1,0),
            #nn.Dropout(0.3),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64,params['output_dim'],1,1,0),
            #nn.MaxPool2d(1),    # output shape (64, Y/8, X/8)
        )
        #self.sa  = self_attention_memory_module(12,1,self.device)
        #self.h = torch.zeros(1, 12, params['Height'], params['Width']).to(self.device)
        self.sa  = SAAttnMem(12,12)

    def forward(self, x):
        
        #output = self.conv1(x) * self.sa(x,self.h)[0]
        #output = self.conv1(self.sa(x,self.h)[0]*x)
        
        #sa = self.sa(x,self.h)[0]
        sa = self.sa(x)
        print(sa.shape)
        output = self.conv1(sa*x)
        #output = self.fc(output)
        #print(output.shape)
        return output,sa   # return x for visualization


class djkajkdlfjlad(nn.Module):  # self-attention convlstm for spatiotemporal prediction model
    def __init__(self, params):
        super(Encode2Decode_SpatialAttention, self).__init__()
        # hyperparams
        self.cells, self.bns, self.decoderCells = [], [], []
        self.n_layers = params['n_layers']
        self.input_window_size = params['input_window_size']
        self.output_window_size = params['output_window_size']
        self.device = params['device']
        self.img_encode = DownSampler(params)
        self.img_decode = UpSampler(params)

        for i in range(params['n_layers']):
            params['input_dim'] == params['hidden_dim'] if i == 0 else params['hidden_dim']
            params['hidden_dim'] == params['hidden_dim']
            self.cells.append(ConvLSTMCell(params))
            self.bns.append(nn.LayerNorm((params['hidden_dim'], 16, 16)))  # Use layernorm

        self.cells = nn.ModuleList(self.cells)
        #self.cells= SA_Convlstm_cell(params)

        self.bns = nn.ModuleList(self.bns)
        self.decoderCells = nn.ModuleList(self.decoderCells)

        # Linear
        self.decode_conv = nn.Conv2d(in_channels=self.output_window_size,
                                     out_channels=self.output_window_size,
                                     kernel_size=(3, 3),
                                     padding=(1, 1))

        self.ct = ConditionTime(params['output_dim'])
        self.image_encoder = TimeDistributed(self.img_encode, low_mem=True)
        self.image_decoder = TimeDistributed(self.img_decode, low_mem=True) #
    def forward(self, x, hidden=None):

        # x = self.ct(x, fstep=0)
        x = self.image_encoder(x)
        x = self.sa(x)
        
        if hidden == None:
            hidden = self.init_hidden(x)

        total_steps = self.input_window_size + self.output_window_size - 1

        for i, cell in enumerate(self.cells):
            out_layer = []
            hid = hidden[i]
            for t in range(total_steps):
                if t < self.input_window_size:
                    input_ = x[:, t]
                else:
                    input_ = out_layer[t - 1]
                out, hid = cell(input_, hid)
                out_layer.append(out)
            out_layer = torch.stack(out_layer, dim=1)  # output predictions
            x = out_layer

        res0 = out_layer[:, self.output_window_size * -1:]

        out = self.image_decoder(res0)

        # for multi var output
        # var0 = self.decode_conv(out[:, :, 0, :])
        # var1 = self.decode_conv(out[:, :, 1, :])
        # var2 = self.decode_conv(out[:, :, 2, :])
        #
        # out = torch.stack([var0, var1, var2], dim=2)

        return torch.tanh(out)

class Encode2Decode_convLSTM_MultiStep(nn.Module):  # self-attention convlstm for spatiotemporal prediction model
    def __init__(self, params):
        super(Encode2Decode_convLSTM_MultiStep, self).__init__()
        # hyperparams
        self.cells, self.bns, self.decoderCells = [], [], []
        self.n_layers = params['n_layers']
        self.input_window_size = params['input_window_size']
        self.output_window_size = params['output_window_size']
        self.device = params['device']
        self.img_encode = DownSampler(params)
        self.img_decode = UpSampler(params)

        for i in range(params['n_layers']):
            params['input_dim'] == params['hidden_dim'] if i == 0 else params['hidden_dim']
            params['hidden_dim'] == params['hidden_dim']
            self.cells.append(ConvLSTMCell(params))
            self.bns.append(nn.LayerNorm((params['hidden_dim'], 16, 16)))  # Use layernorm

        self.cells = nn.ModuleList(self.cells)

        self.bns = nn.ModuleList(self.bns)
        self.decoderCells = nn.ModuleList(self.decoderCells)

        # Linear
        self.decode_conv = nn.Conv2d(in_channels=self.output_window_size,
                                     out_channels=self.output_window_size,
                                     kernel_size=(3, 3),
                                     padding=(1, 1))

        self.ct = ConditionTime(params['output_dim'])
        self.image_encoder = TimeDistributed(self.img_encode, low_mem=True)
        self.image_decoder = TimeDistributed(self.img_decode, low_mem=True) #
    def forward(self, x, hidden=None):

        # x = self.ct(x, fstep=0)
        x = self.image_encoder(x)
        
        if hidden == None:
            hidden = self.init_hidden(x)

        total_steps = self.input_window_size + self.output_window_size - 1

        for i, cell in enumerate(self.cells):
            out_layer = []
            hid = hidden[i]
            for t in range(total_steps):
                if t < self.input_window_size:
                    input_ = x[:, t]
                else:
                    input_ = out_layer[t - 1]
                out, hid = cell(input_, hid)
                out_layer.append(out)
            out_layer = torch.stack(out_layer, dim=1)  # output predictions
            x = out_layer

        res0 = out_layer[:, self.output_window_size * -1:]

        out = self.image_decoder(res0)

        # for multi var output
        # var0 = self.decode_conv(out[:, :, 0, :])
        # var1 = self.decode_conv(out[:, :, 1, :])
        # var2 = self.decode_conv(out[:, :, 2, :])
        #
        # out = torch.stack([var0, var1, var2], dim=2)

        return torch.tanh(out)

    def init_hidden(self, inputs):
        states = []
        batch_size, _, _, height, width = inputs.size()
        for i in range(self.n_layers):
            states.append(self.cells[i].init_hidden(batch_size, (height, width)))
        return states


class Encode2Decode_SAconvLSTM_MultiStep(nn.Module):  # self-attention convlstm for spatiotemporal prediction model
    def __init__(self, params):
        super(Encode2Decode_SAconvLSTM_MultiStep, self).__init__()
        # hyperparams
        self.cells, self.bns, self.decoderCells = [], [], []
        self.n_layers = params['n_layers']
        self.input_window_size = params['input_window_size']
        self.output_window_size = params['output_window_size']
        self.device = params['device']
        self.img_encode = DownSampler(params)
        self.img_decode = UpSampler(params)

        for i in range(params['n_layers']):
            params['input_dim'] == params['hidden_dim'] if i == 0 else params['hidden_dim']
            params['hidden_dim'] == params['hidden_dim']
            self.cells.append(SA_Convlstm_cell(params))
            self.bns.append(nn.LayerNorm((params['hidden_dim'], 16, 16)))  # Use layernorm

        self.cells = nn.ModuleList(self.cells)

        self.bns = nn.ModuleList(self.bns)
        self.decoderCells = nn.ModuleList(self.decoderCells)

        # Linear
        self.decode_conv = nn.Conv2d(in_channels=self.output_window_size,
                                     out_channels=self.output_window_size,
                                     kernel_size=(3, 3),
                                     padding=(1, 1))

        self.ct = ConditionTime(params['output_dim'])
        self.image_encoder = TimeDistributed(self.img_encode, low_mem=True)
        self.image_decoder = TimeDistributed(self.img_decode, low_mem=True) #

    def forward(self, x, hidden=None):

        # x = self.ct(x, fstep=0)
        x = self.image_encoder(x)
        if hidden == None:
            hidden = self.init_hidden(x)

        total_steps = self.input_window_size + self.output_window_size - 1

        for i, cell in enumerate(self.cells):
            out_layer = []
            hid = hidden[i]
            for t in range(total_steps):
                if t < self.input_window_size:
                    input_ = x[:, t]
                else:
                    input_ = out_layer[t - 1]
                out, hid = cell(input_, hid)
                out_layer.append(out)
            out_layer = torch.stack(out_layer, dim=1)  # output predictions
            x = out_layer

        res0 = out_layer[:, self.output_window_size * -1:]

        out = self.image_decoder(res0)

        # for multi var output
        # var0 = self.decode_conv(out[:, :, 0, :])
        # var1 = self.decode_conv(out[:, :, 1, :])
        # var2 = self.decode_conv(out[:, :, 2, :])
        #
        # out = torch.stack([var0, var1, var2], dim=2)

        return torch.tanh(out)

    def init_hidden(self, inputs):
        states = []
        batch_size, _, _, height, width = inputs.size()
        for i in range(self.n_layers):
            states.append(self.cells[i].init_hidden(batch_size, (height, width)))
        return states

