import torch.nn as nn
import torch
from axial_attention import AxialAttention, AxialPositionalEmbedding
import numpy as np


def cuboid_reorder_reverse(data, cuboid_size, strategy, orig_data_shape):
    """Reverse the reordered cuboid back to the original space

    Parameters
    ----------
    data
    cuboid_size
    strategy
    orig_data_shape

    Returns
    -------
    data
        The recovered data
    """
    B, num_cuboids, cuboid_volume, C = data.shape
    T, H, W = orig_data_shape

    permutation_axis = [0]
    for i, (block_size, total_size, ele_strategy) in enumerate(zip(cuboid_size, (T, H, W), strategy)):
        if ele_strategy == 'l':
            # intermediate_shape.extend([total_size // block_size, block_size])
            permutation_axis.append(i + 1)
            permutation_axis.append(i + 4)
        elif ele_strategy == 'd':
            # intermediate_shape.extend([block_size, total_size // block_size])
            permutation_axis.append(i + 4)
            permutation_axis.append(i + 1)
        else:
            raise NotImplementedError
    permutation_axis.append(7)
    data = data.reshape(B, T // cuboid_size[0], H // cuboid_size[1], W // cuboid_size[2],
                        cuboid_size[0], cuboid_size[1], cuboid_size[2], C)
    data = data.permute(permutation_axis)
    data = data.reshape((B, T, H, W, C))
    return data

def masked_softmax(att_score, mask, axis: int = -1):
    """Ignore the masked elements when calculating the softmax.
     The mask can be broadcastable.

    Parameters
    ----------
    att_score
        Shape (..., length, ...)
    mask
        Shape (..., length, ...)
        1 --> The element is not masked
        0 --> The element is masked
    axis
        The axis to calculate the softmax. att_score.shape[axis] must be the same as mask.shape[axis]

    Returns
    -------
    att_weights
        Shape (..., length, ...)
    """
    if mask is not None:
        # Fill in the masked scores with a very small value
        if att_score.dtype == torch.float16:
            att_score = att_score.masked_fill(torch.logical_not(mask), -1E4)
        else:
            att_score = att_score.masked_fill(torch.logical_not(mask), -1E18)
        att_weights = torch.softmax(att_score, dim=axis) * mask
    else:
        att_weights = torch.softmax(att_score, dim=axis)
    return att_weights

def cuboid_reorder(data, cuboid_size, strategy):
    """Reorder the tensor into (B, num_cuboids, bT * bH * bW, C)

    We assume that the tensor shapes are divisible to the cuboid sizes.

    Parameters
    ----------
    data
        The input data
    cuboid_size
        The size of the cuboid
    strategy
        The cuboid strategy

    Returns
    -------
    reordered_data
        Shape will be (B, num_cuboids, bT * bH * bW, C)
        num_cuboids = T / bT * H / bH * W / bW
    """
    B, T, H, W, C = data.shape
    num_cuboids = T // cuboid_size[0] * H // cuboid_size[1] * W // cuboid_size[2]
    cuboid_volume = cuboid_size[0] * cuboid_size[1] * cuboid_size[2]
    intermediate_shape = []

    nblock_axis = []
    block_axis = []
    for i, (block_size, total_size, ele_strategy) in enumerate(zip(cuboid_size, (T, H, W), strategy)):
        if ele_strategy == 'l':
            intermediate_shape.extend([total_size // block_size, block_size])
            nblock_axis.append(2 * i + 1)
            block_axis.append(2 * i + 2)
        elif ele_strategy == 'd':
            intermediate_shape.extend([block_size, total_size // block_size])
            nblock_axis.append(2 * i + 2)
            block_axis.append(2 * i + 1)
        else:
            raise NotImplementedError
    data = data.reshape((B,) + tuple(intermediate_shape) + (C, ))
    reordered_data = data.permute((0,) + tuple(nblock_axis) + tuple(block_axis) + (7,))
    reordered_data = reordered_data.reshape((B, num_cuboids, cuboid_volume, C))
    return reordered_data

class CuboidSelfAttentionLayer(nn.Module):
    """Implements the cuboid self attention.
    """
    def __init__(self,
                 dim,
                 num_heads = 2,
                 cuboid_size=(1, 1, 4),
                 shift_size=(0, 0, 0),
                 strategy=('l', 'l', 'l'),
                 qkv_bias=False,
                 qk_scale=None,
                 attn_drop=0.0,
                 ):
        """
        Parameters
        ----------
        dim
            The dimension of the input tensor
        num_heads
            The number of heads
        cuboid_size
            The size of each cuboid
        shift_size
            The size for shifting the windows.
        strategy
            The decomposition strategy of the tensor. 'l' stands for local and 'd' stands for dilated.
        padding_type
            The type of padding.
        qkv_bias
            Whether to enable bias in calculating qkv attention
        qk_scale
            Whether to enable scale factor when calculating the attention.
        attn_drop
            The attention dropout
        proj_drop
            The projection dropout
        """
        super(CuboidSelfAttentionLayer, self).__init__()
        # initialization
        assert dim % num_heads == 0
        self.num_heads = num_heads
        self.dim = dim
        self.cuboid_size = cuboid_size
        self.shift_size = shift_size
        self.strategy = strategy
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)

    def forward(self, x, mask=None):

        B, T, H, W, C_in = x.shape
        assert C_in == self.dim
        shifted_x = x
        # Step-3: Reorder the tensor
        # (B, num_cuboids, cuboid_volume, C)
        reordered_x = cuboid_reorder(shifted_x, cuboid_size=self.cuboid_size, strategy=self.strategy)
        _, num_cuboids, cuboid_volume, _ = reordered_x.shape
        # Step-4: Perform self-attention
        # (num_cuboids, cuboid_volume, cuboid_volume) 已知本次T=1

        head_C = C_in // self.num_heads
        qkv = self.qkv(reordered_x).reshape(B, num_cuboids, cuboid_volume, 3, self.num_heads, head_C)\
            .permute(3, 0, 4, 1, 2, 5)  # (3, B, num_heads, num_cuboids, cuboid_volume, head_C)
        q, k, v = qkv[0], qkv[1], qkv[2]  # Each has shape (B, num_heads, num_cuboids, cuboid_volume, head_C)
        q = q * self.scale
        attn_score = q @ k.transpose(-2, -1)  # Shape (B, num_heads, num_cuboids, cuboid_volume, cuboid_volume)
        if mask is not None:
            attn_mask = mask.reshape((H * W) // (self.cuboid_size[1] * self.cuboid_size[2]),
                                 self.cuboid_size[1] * self.cuboid_size[2], 1).to(reordered_x.device)
        else:
            attn_mask = None
        attn_score = masked_softmax(attn_score, mask=attn_mask)
        reordered_x = (attn_score @ v).permute(0, 2, 3, 1, 4).reshape(B, num_cuboids, cuboid_volume, self.dim)

        # Step-5: Shift back and slice
        x = cuboid_reorder_reverse(reordered_x, cuboid_size=self.cuboid_size, strategy=self.strategy,
                                           orig_data_shape=(T , H , W ))
        return x


class CNN1_EFAT(nn.Module):
    def __init__(self,in_channels, out_channels, H_in, W_in, mask):
        super(CNN1_EFAT, self).__init__()
        self.H = H_in
        self.W = W_in
        self.middleChannels = 64
        if mask is not None:
            self.mask = torch.from_numpy(mask) #np.tile(mask, (self.middleChannels, 1, 1)))
        else:
            self.mask = None
        num_att_layers = 2
        self.conv1 = nn.Sequential(
                nn.Conv2d(in_channels, 32, 3, 1, 1),
                nn.BatchNorm2d(32),
                nn.Conv2d(32, self.middleChannels, 3, 1, 1),
                nn.BatchNorm2d(self.middleChannels),
                nn.Conv2d(self.middleChannels, self.middleChannels, 3, 1, 1),
                nn.BatchNorm2d(self.middleChannels),
                nn.Conv2d(self.middleChannels, self.middleChannels, 3, 1, 1)
            )
        self.position_embedding = AxialPositionalEmbedding(
            dim=self.middleChannels, shape=(self.H, self.W)
        )
        self.head = nn.Conv2d(self.middleChannels, out_channels, kernel_size=(1, 1))
        self.attLayerLat = CuboidSelfAttentionLayer(self.middleChannels, cuboid_size = (1, 1, 5),strategy=('l', 'l', 'l'))
        self.attLayerLon = CuboidSelfAttentionLayer(self.middleChannels, cuboid_size=(1, 5, 1),strategy=('l', 'l', 'l'))
        # self.temporal_agg = nn.Sequential(
        #     *[
        #         AxialAttention(dim=self.middleChannels, mask = self.mask, dim_index=1, heads=8, num_dimensions=2)
        #         for _ in range(num_att_layers)
        #     ]
        # )
    def forward(self, x):
        x0 = self.conv1(x)
        x1 = self.position_embedding(x0) # incorperate A Lot of NOISE!, but required
        # B, T, _, _ = x1.shape
        # x2 = x1[torch.tile(self.mask, (B, T, 1, 1))].reshape(B, T, -1, 1)
        #x1 = x1.masked_fill(torch.logical_not(self.mask), -1E18)
        #dots = torch.softmax(dots, dim=-1) * self.mask
        # BTHWC
        x2 = torch.permute(torch.unsqueeze(x1, 1), (0, 1, 3, 4, 2))
        if self.mask is not None:
            x3 = self.attLayerLat(x2, self.mask)
            x3 = self.attLayerLon(x3, self.mask)

        else:
            x3 = self.attLayerLat(x2)
            x3 = self.attLayerLon(x3)
        # x1[torch.tile(self.mask, (B, T, 1, 1))] = x3
        x4 = self.head(torch.permute(x3[:, 0], (0,3, 1, 2)))
        #output = self.fc(output)
        #print(output.shape)
        return x4   # return x for visualization
		
		
# class MLP(nn.Module):
#     def __init__(self):
#         super(MLP, self).__init__()
#         self.fc  = nn.Sequential(
#             nn.Linear(2, 256),
#             #nn.Dropout(0.5),
# 			nn.ReLU(),
# 			nn.Linear(256,256),
#             nn.ReLU(),
# 			nn.Linear(256,256),
#             nn.ReLU(),
# 			nn.Linear(256,256),
#             #nn.Dropout(0.5),
# 			nn.ReLU(),
#             nn.Linear(256, 1),
#         )
#
#     def forward(self, x):
#         output = self.fc(x)
#         #print(x.shape)
#         return output   # return x for visualization


