import os
from omegaconf import OmegaConf


cfg = OmegaConf.create()
cfg.root_dir = r"E:\OneDrive\PythonLib\earthFTransformer" #os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
cfg.datasets_dir = os.path.join(cfg.root_dir, "datasets")  # default directory for loading datasets
cfg.pretrained_checkpoints_dir = os.path.join(cfg.root_dir, "pretrained_checkpoints")  # default directory for saving and loading pretrained checkpoints
cfg.exps_dir = os.path.join(cfg.root_dir, "experiments")  # default directory for saving experiment results
os.makedirs(cfg.exps_dir, exist_ok=True)
os.makedirs(cfg.datasets_dir, exist_ok=True)
os.makedirs(cfg.pretrained_checkpoints_dir, exist_ok=True)
